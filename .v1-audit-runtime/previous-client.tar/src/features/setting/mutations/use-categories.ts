import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { CategoryInput } from "../types";
import { categoryKeys } from "../query/query-keys";
import { categoryService } from "../services/category.service";
import { syncService } from "@/shared/lib/infrastructure/sync/sync-service";
import { categoryRefreshService } from "../services/category-refresh.service";
import { notifySubscriptionRestriction } from "@/shared/access/subscription-limit";
import { dashboardKeys } from "@/features/app/dashboard/query/dashboard-query-keys";

export function useCategories() {
  return useQuery({
    queryKey: categoryKeys.all,
    queryFn: categoryService.getAll,
  });
}

export function useCreateCategory() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: categoryService.create,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: categoryKeys.all });
      queryClient.invalidateQueries({ queryKey: dashboardKeys.all });
      void syncService.sync();
    },
    onError: notifySubscriptionRestriction,
  });
}

export function useUpdateCategory() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: number; data: CategoryInput }) =>
      categoryService.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: categoryKeys.all });
      queryClient.invalidateQueries({ queryKey: dashboardKeys.all });
      void syncService.sync();
    },
    onError: notifySubscriptionRestriction,
  });
}

export function useDeleteCategory() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: categoryService.remove,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: categoryKeys.all });
      queryClient.invalidateQueries({ queryKey: dashboardKeys.all });
      void syncService.sync();
    },
  });
}

export function useReactivateCategory() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: categoryService.reactivate,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: categoryKeys.all });
      queryClient.invalidateQueries({ queryKey: dashboardKeys.all });
      void syncService.sync();
    },
  });
}

export function useRefreshCategoriesFromServer() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () => categoryRefreshService.refreshFromServer(),
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: categoryKeys.all }),
  });
}
