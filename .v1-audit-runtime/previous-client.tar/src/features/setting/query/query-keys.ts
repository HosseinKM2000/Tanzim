export const industryKeys = {
  all: ["industries"] as const,
};
export const categoryKeys = {
  all: ["categories"] as const,
};

export const exportKeys = {
  all: ["export"] as const,
  localProducts: ["export", "local-products"] as const,
};

export const adminKeys = {
  all: ["admin"] as const,
  users: ["admin", "users"] as const,
  plans: ["admin", "plans"] as const,
  entitlementRegistry: ["admin", "entitlement-registry"] as const,
  subscribers: (planId: string) => ["admin", "plans", planId, "subscribers"] as const,
  audit: ["admin", "audit"] as const,
};

export const planKeys = {
  all: ["plans"] as const,
  current: ["plans", "current"] as const,
};
export const catalogProductKeys = {
  all: ["catalog-products"] as const,

  lists: () => [...catalogProductKeys.all, "list"] as const,

  list: (params?: { search?: string; industry_id?: number }) =>
    [...catalogProductKeys.lists(), "active", params ?? {}] as const,

  infinite: (params?: { search?: string; industry_id?: number }) =>
    [...catalogProductKeys.lists(), "cursor-v2", params ?? {}] as const,

  archivedList: (params?: { search?: string; industry_id?: number }) =>
    [...catalogProductKeys.lists(), "archived", params ?? {}] as const,

  details: () => [...catalogProductKeys.all, "detail"] as const,

  detail: (id: number) => [...catalogProductKeys.details(), id] as const,

  adoptionStatus: () => [...catalogProductKeys.all, "adoption-status"] as const,
};
