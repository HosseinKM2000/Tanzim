import type { Product } from "../types";
import { createLocalEntityId } from "@/shared/lib/infrastructure/storage/local-entity-id";

export function createProductInitialValues(initial?: Product) {
  const now = new Date().toISOString();

  return {
    id: initial?.id ?? createLocalEntityId(),

    catalog_product_id:
      initial?.catalog_product_id ?? initial?.catalog_product?.id ?? 0,

    is_catalog_backed: initial?.is_catalog_backed ?? false,

    category_id: initial?.category_id ?? null,

    label_ids: initial?.label_ids ?? [],

    quantity: initial?.quantity ?? 0,

    price: initial?.price ?? 0,

    sale_price: initial?.sale_price ?? (initial?.price_missing ? null : initial?.price ?? null),

    purchase_price: initial?.purchase_price ?? null,

    price_missing: initial?.price_missing ?? false,

    custom_label: initial?.custom_label ?? "",

    note: initial?.note ?? null,

    low_stock_threshold: initial?.low_stock_threshold ?? 0,

    low_stock_alert: initial?.low_stock_alert ?? false,

    is_hidden: initial?.is_hidden ?? false,

    image_url: initial?.image_url ?? null,

    deleted_at: initial?.deleted_at ?? null,

    status: initial?.status ?? "out_of_stock",

    created_at: initial?.created_at ?? now,

    updated_at: initial?.updated_at ?? now,

    catalog_product: {
      id: initial?.catalog_product?.id ?? 0,

      industry_id: initial?.catalog_product?.industry_id ?? 0,

      is_active: initial?.catalog_product?.is_active ?? true,

      name: initial?.catalog_product?.name ?? "",

      description: initial?.catalog_product?.description ?? null,

      brand: initial?.catalog_product?.brand ?? null,

      image_url: initial?.catalog_product?.image_url ?? null,

      is_packaged: initial?.catalog_product?.is_packaged ?? false,

      pack_size: initial?.catalog_product?.pack_size ?? null,

      created_at: initial?.catalog_product?.created_at ?? now,
    },

    image: null,

    remove_image: false,
  };
}
