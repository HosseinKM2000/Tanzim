import { imageService } from "@/shared/lib/infrastructure/media/image.service";
import { isLocalImage } from "@/shared/lib/infrastructure/media/image.service";
import { mediaTransferService } from "@/shared/lib/infrastructure/media/media-transfer.service";
import { db } from "@/shared/lib/infrastructure/storage/db";
import { queueService } from "@/shared/lib/infrastructure/sync/queue.service";
import { accessState } from "@/shared/access/access-state";
import { localMutationStorage } from "@/shared/lib/infrastructure/storage/local-mutation-storage";
import { isTeamMode, teamCommandService } from "@/shared/lib/infrastructure/sync/team-command.service";

import { inventoryRepository } from "./inventory.repository";

import type { Product, ProductInput, ProductListParams } from "../types";
import { validPackSize } from "../domain/packaging";
import { labelStorage } from "@/shared/lib/infrastructure/storage/label-storage";
import { isProductEligible } from "../domain/product-eligibility";
import { barcodeLookupCandidates, generateInternalBarcode, inferSymbology, INTERNAL_BARCODE_SYMBOLOGY, validateBarcode } from "@/features/barcode/domain/barcode";
import { barcodeRepository } from "@/features/barcode/services/barcode-repository";
import type { PendingBarcodeInput, ProductBarcode } from "@/features/barcode/types";
import { categoryStorage } from "@/shared/lib/infrastructure/storage/category-storage";
import { createLocalEntityId } from "@/shared/lib/infrastructure/storage/local-entity-id";
import { syncMetadataStorage } from "@/shared/lib/infrastructure/storage/sync-metadata-storage";
import { assertProductQuantity, productQuantityError } from "../domain/inventory-quantity";

export type BulkProductIntent = {
  categoryId?: number | null;
  priceIncrease?: number;
  lowStockAlert?: boolean;
  lowStockThreshold?: number;
};

export const PRODUCT_ENTITY = "product";

/** Local products have no server version yet and must be created, not updated. */
export function productSyncAction(product: Product): "CREATE" | "UPDATE" {
  return product.version == null ? "CREATE" : "UPDATE";
}

export function normalizeProductSearch(value: string) {
  return value.normalize("NFC").trim().replace(/\s+/g, " ").toLocaleLowerCase("fa");
}

function sanitize(product: Product): Product {
  // Local data is never trusted blindly — it may come from an older schema,
  // a corrupted record or a future import.
  const quantity = Number(product.quantity);

  const legacyPrice = Number(product.price);
  const saleCandidate = product.sale_price === undefined
    ? (product.price_missing === true || product.price == null || !Number.isFinite(legacyPrice) ? null : legacyPrice)
    : product.sale_price;
  const salePrice = saleCandidate == null ? null : Number(saleCandidate);
  const purchasePrice = product.purchase_price == null ? null : Number(product.purchase_price);
  const priceMissing = salePrice == null || !Number.isSafeInteger(salePrice) || salePrice < 0;

  const threshold = Number(product.low_stock_threshold);

  const safeQuantity = productQuantityError(quantity) == null ? quantity : 0;

  const safeThreshold = Number.isFinite(threshold) ? Math.max(0, threshold) : 0;
  const packaged =
    product.catalog_product?.is_packaged === true &&
    validPackSize(product.catalog_product.pack_size);

  const status =
    safeQuantity <= 0
      ? "out_of_stock"
      : safeThreshold > 0 && safeQuantity <= safeThreshold
        ? "low_stock"
        : "in_stock";

  return {
    ...product,

    category_id: product.category_id ?? null,

    label_ids: Array.isArray(product.label_ids)
      ? [...new Set(product.label_ids.filter(Number.isSafeInteger))]
      : [],

    quantity: safeQuantity,

    price: priceMissing ? 0 : salePrice,

    sale_price: priceMissing ? null : salePrice,

    purchase_price: Number.isSafeInteger(purchasePrice) && purchasePrice! >= 0 ? purchasePrice : null,

    price_missing: priceMissing,

    low_stock_threshold: safeThreshold,

    low_stock_alert: Boolean(product.low_stock_alert),

    is_hidden: Boolean(product.is_hidden),

    is_catalog_backed: Boolean(product.is_catalog_backed),

    catalog_product_id:
      Number(product.catalog_product_id) || product.catalog_product?.id || 0,

    catalog_product: product.catalog_product
      ? {
          ...product.catalog_product,
          is_packaged: packaged,
          pack_size: packaged ? product.catalog_product.pack_size : null,
        }
      : undefined,

    image_url: typeof product.image_url === "string" ? product.image_url : null,

    status,
  };
}

async function prepareCreationBarcodes(
  record: Product,
  pendingBarcodes: PendingBarcodeInput[],
  occupiedValues: Set<string>,
): Promise<{ barcodes: ProductBarcode[]; commandFields: Record<string, unknown> }> {
  const now = new Date().toISOString();
  const barcodes: ProductBarcode[] = [];
  for (const input of pendingBarcodes) {
    if (input.source !== "manufacturer") throw new Error("بارکد داخلی فقط توسط فرایند امن ثبت محصول صادر می‌شود");
    const symbology = inferSymbology(input.value);
    const validation = validateBarcode(input.value, symbology);
    if (!validation.valid) throw new Error(validation.error);
    if (occupiedValues.has(input.value)) throw new Error("این بارکد در همین فروشگاه قبلاً رزرو شده است");
    if (!Number.isSafeInteger(input.scanQuantity) || input.scanQuantity < 1 || (input.meaning === "unit" && input.scanQuantity !== 1)) {
      throw new Error("تعداد هر اسکن بارکد معتبر نیست");
    }
    occupiedValues.add(input.value);
    barcodes.push({
      id: createLocalEntityId(), product_id: record.id, value: input.value, source: "manufacturer",
      symbology, meaning: input.meaning, scan_quantity: input.scanQuantity, is_active: true,
      is_default: barcodes.length === 0, lifecycle_status: "active", reservation_id: null,
      category_reference_key: null, created_at: now, updated_at: now,
    });
  }
  if (barcodes.length === 0 && record.category_id != null) {
    const category = await categoryStorage.get(record.category_id);
    if (category?.is_active !== false && category?.sector_code && category.code) {
      const value = await generateInternalBarcode({
        sectorCode: category.sector_code,
        categoryCode: category.code,
        exists: async (candidate) => occupiedValues.has(candidate),
      });
      occupiedValues.add(value);
      barcodes.push({
        id: createLocalEntityId(), product_id: record.id, value, source: "tanzim", symbology: INTERNAL_BARCODE_SYMBOLOGY,
        meaning: "unit", scan_quantity: 1, is_active: true, is_default: true, lifecycle_status: "active",
        reservation_id: null, category_reference_key: category.reference_key ?? null, created_at: now, updated_at: now,
      });
    }
  }
  const commandFields = barcodes.length === 0
    ? {}
    : barcodes[0].source === "tanzim"
      ? { internal_barcode: barcodes[0] }
      : { external_barcodes: barcodes };
  return { barcodes, commandFields };
}

class InventoryService {
  async getAll(params: ProductListParams = {}): Promise<Product[]> {
    let products = (await inventoryRepository.getAll())
      .map(sanitize)
      .filter((product) => isProductEligible(product, {
        includeHidden: params.include_hidden !== false,
        hideCatalogProducts: params.hide_catalog_products,
      }));

    // Search
    if (params.search) {
      const search = normalizeProductSearch(params.search);
      const labels = new Map((await labelStorage.getAll()).map((label) => [label.id, normalizeProductSearch(label.name)]));
      const barcodeCandidates = barcodeLookupCandidates(params.search, inferSymbology(params.search));
      const barcodeProductIds = new Set((await Promise.all(barcodeCandidates.map((value) => barcodeRepository.findByValue(value))))
        .flat().filter((barcode) => barcode.is_active).map((barcode) => barcode.product_id));

      products = products.filter((product) => {
        const name = normalizeProductSearch(product.catalog_product?.name ?? "");

        const label = normalizeProductSearch(product.custom_label ?? "");

        const labelMatch = product.label_ids?.some((id) => labels.get(id)?.includes(search)) ?? false;
        return name.includes(search) || label.includes(search) || labelMatch || barcodeProductIds.has(product.id);
      });
    }

    if (params.category_id != null) {
      products = products.filter((product) => product.category_id === params.category_id);
    }

    if (params.label_ids?.length) {
      const selectedLabels = new Set(params.label_ids);
      products = products.filter((product) =>
        product.label_ids?.some((labelId) => selectedLabels.has(labelId)) ?? false
      );
    }

    // Every inventory consumer gets deterministic newest-first ordering unless
    // it explicitly requests a different user-selected sort.
    const sort = params.sort ?? "newest";
    products = [...products].sort((a, b) => {
      switch (sort) {
        case "newest":
          return (
            new Date(b.created_at).getTime() -
              new Date(a.created_at).getTime() ||
            b.id - a.id
          );

        case "oldest":
          return (
            new Date(a.created_at).getTime() -
              new Date(b.created_at).getTime() ||
            a.id - b.id
          );

        case "price_high":
          return b.price - a.price;

        case "price_low":
          return a.price - b.price;

        case "quantity_high":
          return b.quantity - a.quantity;

        case "quantity_low":
          return a.quantity - b.quantity;

        default:
          return 0;
      }
    });

    return products;
  }

  async get(id: number): Promise<Product | undefined> {
    const product = await inventoryRepository.get(id);

    return product ? sanitize(product) : undefined;
  }

  async create(product: Product, pendingBarcodes: PendingBarcodeInput[] = []): Promise<Product> {
    accessState.requireWrite();
    accessState.requireStorePermission?.("products.create");
    if (product.purchase_price != null) accessState.requireStorePermission?.("products.purchase_price.change");
    const existingProducts = await inventoryRepository.getAll();
    if (product.is_catalog_backed && Number.isSafeInteger(product.catalog_product_id) && product.catalog_product_id > 0) {
      const existingAdoption = existingProducts.find((item) =>
        item.is_catalog_backed && item.catalog_product_id === product.catalog_product_id && !item.deleted_at,
      );
      if (existingAdoption) return sanitize(existingAdoption);
    }
    accessState.requireInventoryCapacity(existingProducts.length);
    assertProductQuantity(Number(product.quantity));
    const record = sanitize(product);
    const mediaJob = isLocalImage(record.image_url)
      ? await mediaTransferService.stage(record.image_url, record.id)
      : null;
    const occupiedValues = new Set((await barcodeRepository.getAll()).map((barcode) => barcode.value));
    const { barcodes: creationBarcodes, commandFields: embeddedBarcodePayload } =
      await prepareCreationBarcodes(record, pendingBarcodes, occupiedValues);
    const commandPayload: Record<string, unknown> = mediaJob
      ? { ...record, media_transfer_id: mediaJob.transferId }
      : { ...record };
    Object.assign(commandPayload, embeddedBarcodePayload);
    if (mediaJob) delete commandPayload.image_url;

    if (isTeamMode()) {
      if (mediaJob) await mediaTransferService.persist(mediaJob);
      await teamCommandService.submit(PRODUCT_ENTITY, record.id, "CREATE", commandPayload);
      const confirmed = await inventoryRepository.get(record.id);
      if (!confirmed) throw new Error("TEAM_RESULT_MISSING");
      if (mediaJob) {
        const local = { ...confirmed, image_url: mediaJob.localPath, server_image_url: confirmed.image_url };
        await inventoryRepository.save(local);
        return local;
      }
      return confirmed;
    }

    return localMutationStorage.inventoryWithBarcodes(async () => {
      await inventoryRepository.save(record);
      if (creationBarcodes.length) await barcodeRepository.saveMany(creationBarcodes);
      if (mediaJob) await db.mediaTransfers.put(mediaJob);

      const saved = await inventoryRepository.get(record.id);
      if (!saved) throw new Error("product was not saved");

      await queueService.enqueue(PRODUCT_ENTITY, saved.id, "CREATE", commandPayload);
      return saved;
    });
  }

  async createMany(products: Product[], pendingBarcodes: PendingBarcodeInput[][] = []): Promise<Product[]> {
    accessState.requireWrite();
    accessState.requireStorePermission?.("products.create");
    accessState.requireStorePermission?.("products.bulk");
    if (products.some((product) => product.purchase_price != null)) accessState.requireStorePermission?.("products.purchase_price.change");
    const existing = (await inventoryRepository.getAll()).length;
    accessState.requireInventoryCapacity(existing + products.length);
    const records = products.map(sanitize);
    const occupiedValues = new Set((await barcodeRepository.getAll()).map((barcode) => barcode.value));
    const prepared: Array<{ record: Product; barcodes: ProductBarcode[]; command: Record<string, unknown> }> = [];
    for (let index = 0; index < records.length; index += 1) {
      const record = records[index];
      const result = await prepareCreationBarcodes(record, pendingBarcodes[index] ?? [], occupiedValues);
      prepared.push({ record, barcodes: result.barcodes, command: { ...record, ...result.commandFields } });
    }
    if (isTeamMode()) {
      const confirmed: Product[] = [];
      for (const { record, command } of prepared) {
        await teamCommandService.submit(PRODUCT_ENTITY, record.id, "CREATE", command);
        const saved = await inventoryRepository.get(record.id);
        if (!saved) throw new Error("TEAM_RESULT_MISSING");
        confirmed.push(saved);
      }
      return confirmed;
    }
    return localMutationStorage.inventoryWithBarcodes(async () => {
      for (const { record, barcodes, command } of prepared) {
        await inventoryRepository.save(record);
        if (barcodes.length) await barcodeRepository.saveMany(barcodes);
        await queueService.enqueue(PRODUCT_ENTITY, record.id, "CREATE", command);
      }
      return records;
    });
  }

  async bulkUpdate(ids: readonly number[], intent: BulkProductIntent): Promise<Product[]> {
    accessState.requireWrite();
    accessState.requireStorePermission?.("products.bulk");
    if (intent.priceIncrease !== undefined) accessState.requireStorePermission?.("products.sale_price.change");
    if (intent.categoryId !== undefined) accessState.requireStorePermission?.("categories.manage");
    if (intent.lowStockAlert !== undefined || intent.lowStockThreshold !== undefined) accessState.requireStorePermission?.("products.edit");
    const uniqueIds = [...new Set(ids)];
    if (uniqueIds.length === 0) throw new Error("هیچ محصولی انتخاب نشده است");
    if (intent.priceIncrease !== undefined &&
        (!Number.isSafeInteger(intent.priceIncrease) || intent.priceIncrease < 0)) {
      throw new Error("افزایش قیمت باید عدد صحیح و نامنفی باشد");
    }
    if (intent.lowStockThreshold !== undefined &&
        (!Number.isSafeInteger(intent.lowStockThreshold) || intent.lowStockThreshold < 0)) {
      throw new Error("حد هشدار باید عدد صحیح و نامنفی باشد");
    }
    const hasEffectiveChange = intent.categoryId !== undefined ||
      (intent.priceIncrease ?? 0) > 0 || intent.lowStockAlert !== undefined ||
      intent.lowStockThreshold !== undefined;
    if (!hasEffectiveChange) throw new Error("حداقل یک تغییر مؤثر انتخاب کنید");
    if (intent.categoryId !== undefined && await syncMetadataStorage.getString("taxonomy-version")) {
      throw new Error("CATEGORY_CHANGE_REQUIRES_PREVIEW");
    }

    if (isTeamMode()) {
      const updated: Product[] = [];
      for (const id of uniqueIds) {
        const current = await inventoryRepository.get(id);
        if (!current) continue;
        const price = intent.priceIncrease ? current.price + intent.priceIncrease : current.price;
        const payload = {
          id,
          version: current.version,
          ...(intent.categoryId !== undefined ? { category_id: intent.categoryId } : {}),
          ...(intent.lowStockAlert !== undefined ? { low_stock_alert: intent.lowStockAlert } : {}),
          ...(intent.lowStockThreshold !== undefined ? { low_stock_threshold: intent.lowStockThreshold } : {}),
          ...(intent.priceIncrease ? { sale_price: price, price, price_missing: false } : {}),
        };
        await teamCommandService.submit(PRODUCT_ENTITY, id, productSyncAction(current), payload);
        const saved = await inventoryRepository.get(id);
        if (saved) updated.push(saved);
      }
      if (!updated.length) throw new Error("TEAM_RESULT_MISSING");
      return updated;
    }

    return localMutationStorage.inventory(async () => {
      const updated: Product[] = [];
      for (const id of uniqueIds) {
        const current = await inventoryRepository.get(id);
        if (!current) continue;
        const price = intent.priceIncrease
          ? current.price + intent.priceIncrease
          : current.price;
        if (!Number.isSafeInteger(price)) throw new Error("قیمت نهایی از محدوده مجاز خارج است");
        const next = sanitize({
          ...current,
          ...(intent.categoryId !== undefined ? { category_id: intent.categoryId } : {}),
          ...(intent.lowStockAlert !== undefined ? { low_stock_alert: intent.lowStockAlert } : {}),
          ...(intent.lowStockThreshold !== undefined ? { low_stock_threshold: intent.lowStockThreshold } : {}),
          price,
          sale_price: price,
          ...(intent.priceIncrease ? { price_missing: false } : {}),
          updated_at: new Date().toISOString(),
        });
        await inventoryRepository.save(next);
        await queueService.enqueue(PRODUCT_ENTITY, id, productSyncAction(current), current.version == null ? next : { id, version: current.version, sale_price: price, price });
        updated.push(next);
      }
      if (updated.length === 0) throw new Error("محصول انتخاب‌شده دیگر در دسترس نیست");
      return updated;
    });
  }

  async update(id: number, input: ProductInput): Promise<Product> {
    accessState.requireWrite();
    if (input.quantity !== undefined) assertProductQuantity(Number(input.quantity));
    if (input.quantity !== undefined) accessState.requireStorePermission?.("products.quantity.change");
    if (input.price !== undefined || input.sale_price !== undefined) accessState.requireStorePermission?.("products.sale_price.change");
    if (input.purchase_price !== undefined) accessState.requireStorePermission?.("products.purchase_price.change");
    if (Object.keys(input).some((key) => !["quantity", "price", "sale_price", "purchase_price"].includes(key))) accessState.requireStorePermission?.("products.edit");
    const current = await inventoryRepository.get(id);

    if (!current) {
      throw new Error("product not found");
    }
    if (
      input.category_id !== undefined
      && input.category_id !== current.category_id
      && await syncMetadataStorage.getString("taxonomy-version")
    ) {
      throw new Error("CATEGORY_CHANGE_REQUIRES_PREVIEW");
    }

    const updated = sanitize({
      ...current,

      ...input,

      ...(input.sale_price !== undefined
        ? { price: input.sale_price ?? 0, sale_price: input.sale_price, price_missing: input.sale_price == null }
        : input.price !== undefined ? { sale_price: input.price, price_missing: false } : {}),

      updated_at: new Date().toISOString(),
    } as Product);

    const payload = current.version == null
      ? updated
      : { id, version: current.version, ...input, ...(input.sale_price !== undefined ? { price: input.sale_price ?? 0, price_missing: input.sale_price == null } : {}) };
    const mediaJob = isLocalImage(updated.image_url) && updated.image_url !== current.image_url
      ? await mediaTransferService.stage(updated.image_url, id)
      : null;
    const commandPayload: Record<string, unknown> = mediaJob
      ? { ...payload, media_transfer_id: mediaJob.transferId }
      : payload;
    if (mediaJob) delete commandPayload.image_url;
    if (isTeamMode()) {
      if (mediaJob) await mediaTransferService.persist(mediaJob);
      await teamCommandService.submit(PRODUCT_ENTITY, id, productSyncAction(current), commandPayload);
      const confirmed = await inventoryRepository.get(id);
      if (!confirmed) throw new Error("TEAM_RESULT_MISSING");
      if (mediaJob) {
        const local = { ...confirmed, image_url: mediaJob.localPath, server_image_url: confirmed.image_url };
        await inventoryRepository.save(local);
        return local;
      }
      return confirmed;
    }

    const saved = await localMutationStorage.inventory(async () => {
      await inventoryRepository.save(updated);
      if (mediaJob) await db.mediaTransfers.put(mediaJob);

      const persisted = await inventoryRepository.get(id);
      if (!persisted) throw new Error("update failed");

      await queueService.enqueue(PRODUCT_ENTITY, id, productSyncAction(current), commandPayload);
      return persisted;
    });

    if (current.image_url && current.image_url !== saved.image_url) {
      // OPFS cannot participate in an IndexedDB transaction. Metadata and the
      // outbox commit first; orphan cleanup is recoverable on the next start.
      try {
        await imageService.remove(current.image_url);
      } catch {
        // cleanupImages retries orphan removal on the next application start
      }
    }

    return saved;
  }

  async adjustQuantity(id: number, delta: number): Promise<Product> {
    accessState.requireWrite();

    if (!Number.isSafeInteger(delta) || delta === 0) {
      throw new Error("تغییر موجودی باید یک عدد صحیح و غیر صفر باشد");
    }

    const current = await inventoryRepository.get(id);

    if (!current || current.deleted_at) {
      throw new Error("محصول برای تغییر موجودی در دسترس نیست");
    }

    const currentQuantity = Number(current.quantity);

    if (!Number.isSafeInteger(currentQuantity) || currentQuantity < 0) {
      throw new Error("موجودی فعلی محصول معتبر نیست");
    }

    const quantity = currentQuantity + delta;

    assertProductQuantity(quantity);

    // Apply the confirmed delta to the latest local record. This preserves a
    // newer local quantity instead of overwriting it with a stale preview.
    return this.update(id, { quantity });
  }

  async remove(id: number): Promise<void> {
    accessState.requireWrite();
    accessState.requireStorePermission?.("products.delete");
    const current = await inventoryRepository.get(id);

    if (!current) {
      throw new Error("محصول یافت نشد");
    }

    if (current.is_catalog_backed) {
      throw new Error(
        "محصولات کاتالوگی قابل حذف نیستند. می‌توانید آن‌ها را مخفی کنید.",
      );
    }

    if (isTeamMode()) {
      await teamCommandService.submit(PRODUCT_ENTITY, id, "DELETE", null);
      return;
    }

    await localMutationStorage.inventory(async () => {
      await inventoryRepository.remove(id);
      await queueService.enqueue(PRODUCT_ENTITY, id, "DELETE", null);
    });

    // The durable delete is authoritative. A failed OPFS cleanup is retried by
    // cleanupImages and must not turn a committed local mutation into failure.
    try {
      await imageService.remove(current.image_url);
    } catch {
      // cleanupImages retries orphan removal on the next application start
    }
  }

  async bulkRemove(ids: readonly number[]): Promise<number[]> {
    accessState.requireWrite();
    accessState.requireStorePermission?.("products.bulk");
    accessState.requireStorePermission?.("products.delete");
    const uniqueIds = [...new Set(ids)];
    if (uniqueIds.length === 0) {
      throw new Error("هیچ محصولی برای حذف انتخاب نشده است");
    }

    const products: Product[] = [];
    for (const id of uniqueIds) {
      const product = await inventoryRepository.get(id);
      if (!product) throw new Error("یکی از محصولات انتخاب‌شده دیگر در دسترس نیست");
      products.push(product);
    }

    if (products.some((product) => product.is_catalog_backed)) {
      throw new Error(
        "محصولات کاتالوگی قابل حذف نیستند. آن‌ها را از انتخاب خارج کنید یا مخفی کنید.",
      );
    }


    if (isTeamMode()) {
      for (const product of products) {
        await teamCommandService.submit(PRODUCT_ENTITY, product.id, "DELETE", null);
      }
      return uniqueIds;
    }

    await localMutationStorage.inventory(async () => {
      for (const product of products) {
        await inventoryRepository.remove(product.id);
        await queueService.enqueue(PRODUCT_ENTITY, product.id, "DELETE", null);
      }
    });

    await Promise.allSettled(
      products.map((product) => imageService.remove(product.image_url)),
    );

    return uniqueIds;
  }

  /** Removes OPFS files that no product references any more. */
  async cleanupImages(): Promise<string[]> {
    const products = await inventoryRepository.getAllStored();

    return imageService.removeOrphans(
      products.map((product) => product.image_url),
      { purpose: "product" },
    );
  }
}

export const inventoryService = new InventoryService();
