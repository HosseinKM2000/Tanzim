import { pushJsonBatch } from "@/features/app/inventory/api/sync.api";
import { inventoryRepository } from "@/features/app/inventory/services/inventory.repository";
import type { SyncQueueItem } from "@/shared/lib/infrastructure/storage/types";
import { registerSyncHandler, type SyncHandlerResult } from "@/shared/lib/infrastructure/sync/sync-service";
import { queueService } from "@/shared/lib/infrastructure/sync/queue.service";
import type { InventoryMovement } from "../types";
import { INVENTORY_MOVEMENT_ENTITY } from "./movement-service";
import { movementRepository } from "./movement-repository";
import { assertSyncAccountCurrent, captureSyncAccountContext } from "@/shared/lib/infrastructure/sync/sync-account-context";

async function push(items: SyncQueueItem[]): Promise<SyncHandlerResult[]> {
  const account = captureSyncAccountContext();
  const response = await pushJsonBatch(items);
  assertSyncAccountCurrent(account);
  const output: SyncHandlerResult[] = [];
  for (const result of response.results) {
    assertSyncAccountCurrent(account);
    const item = items.find((candidate) => candidate.operationId === result.operation_id);
    if (!item) continue;
    const movement = item.payload as InventoryMovement;
    const record = result.record as { movement?: InventoryMovement; product?: import("@/features/app/inventory/types").Product } | null;
    const hasSuccessor = await queueService.hasSuccessor(item);
    assertSyncAccountCurrent(account);
    if (result.status === "applied") {
      await movementRepository.save({ ...movement, ...record?.movement, sync_status: "accepted", updated_at: record?.movement?.updated_at ?? new Date().toISOString() });
      if (record?.product && !hasSuccessor) await inventoryRepository.save(record.product);
    } else {
      await movementRepository.save({ ...movement, sync_status: result.status === "conflict" ? "conflict" : "rejected", updated_at: new Date().toISOString() });
      if (record?.product && !hasSuccessor) await inventoryRepository.save(record.product);
      else if (result.status === "fatal_error") {
        const current = await inventoryRepository.get(movement.product_id);
        if (current) {
          const quantity = Math.max(0, current.quantity - movement.delta);
          const status = quantity <= 0 ? "out_of_stock" : current.low_stock_threshold > 0 && quantity <= current.low_stock_threshold ? "low_stock" : "in_stock";
          await inventoryRepository.save({ ...current, quantity, status, updated_at: new Date().toISOString() });
        }
      }
    }
    output.push({ itemId: item.id, status: result.status, error: result.error });
  }
  return output;
}

export function registerMovementSync() {
  registerSyncHandler(INVENTORY_MOVEMENT_ENTITY, push);
}
