import hashlib
import json
import os
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

import pytest
from pydantic import ValidationError

os.environ.setdefault("ENVIRONMENT", "test")
os.environ.setdefault("DATABASE_URL", "sqlite:///:memory:")

from app.plans import PLAN_CATALOG, subscription_expired
from app.schemas import CatalogProductCreate, InventoryCreate, InventoryUpdate, PasswordUpdate, SyncBatchRequest
from app.security import hash_password, verify_password
from app.services.authorization_service import Permission, RoleId, has_permission, set_role
from app.services import plan_policy
from app.services.tool_policy import DEFAULT_TOOL_POLICY, normalize_tool_policy
from app.demo_fixture import _assert_safe
from app.services.jalali_date import format_jalali_datetime
from app.services.store_authorization import StorePermission, normalize_permissions
from app.routers.sync import _project_record
from app.inventory_policy import PRODUCT_QUANTITY_LIMIT_ERROR, validate_product_quantity
from app.reference_storage import ReferenceAssetStorage
from app.services.catalog_reference_service import _canonical_json, _sealed_manifest


def test_bcrypt_hashes_and_verifies_without_storing_plaintext() -> None:
    password = "StrongPass123!"
    hashed = hash_password(password)
    assert hashed != password
    assert hashed.startswith("$2")
    assert verify_password(password, hashed)
    assert not verify_password("WrongPass123!", hashed)


@pytest.mark.parametrize("password", ["alllowercase1", "ALLUPPERCASE1", "NoNumberHere"])
def test_password_update_rejects_weak_passwords(password: str) -> None:
    with pytest.raises(ValidationError):
        PasswordUpdate(current_password="CurrentPass123!", new_password=password)


def test_password_schema_enforces_bcrypt_utf8_limit() -> None:
    with pytest.raises(ValidationError, match="PASSWORD_TOO_LONG"):
        PasswordUpdate(current_password="CurrentPass123!", new_password="A1a" + "é" * 35)


def test_financial_permissions_expand_to_required_read_dependencies() -> None:
    permissions = normalize_permissions([StorePermission.FINANCE_VIEW.value])
    assert StorePermission.PURCHASE_PRICE_VIEW.value in permissions
    assert StorePermission.SALE_PRICE_VIEW.value in permissions
    assert StorePermission.PRODUCTS_VIEW.value in permissions
    assert StorePermission.DASHBOARD_VIEW.value in permissions


def test_sync_projection_redacts_purchase_price_and_preserves_legacy_clients() -> None:
    record = {"id": 1, "price": 120, "sale_price": 120, "purchase_price": 75, "price_missing": False}
    viewer = frozenset({StorePermission.PRODUCTS_VIEW.value, StorePermission.SALE_PRICE_VIEW.value})
    assert _project_record(record, viewer, 3) == {**record, "purchase_price": None}
    assert _project_record(record, viewer, 2) == {"id": 1, "price": 120}


def test_sync_projection_hides_sale_price_without_explicit_visibility() -> None:
    record = {"id": 1, "price": 120, "sale_price": 120, "purchase_price": 75, "price_missing": False}
    projected = _project_record(record, frozenset(), 3)
    assert projected["sale_price"] is None
    assert projected["price"] == 0
    assert projected["price_missing"] is True
    assert projected["purchase_price"] is None


def test_catalog_packaging_contract_normalizes_or_rejects_invalid_metadata() -> None:
    unpackaged = CatalogProductCreate(industry_id=1, name="  Item  ", is_packaged=False, pack_size=12)
    assert unpackaged.name == "Item"
    assert unpackaged.pack_size is None
    with pytest.raises(ValidationError, match="PACK_SIZE_REQUIRED"):
        CatalogProductCreate(industry_id=1, name="Item", is_packaged=True, pack_size=None)
    with pytest.raises(ValidationError):
        CatalogProductCreate(industry_id=1, name="Item", is_packaged=True, pack_size=0)


@pytest.mark.parametrize("field", ["quantity", "price", "low_stock_threshold"])
def test_inventory_payload_rejects_negative_values(field: str) -> None:
    with pytest.raises(ValidationError):
        InventoryCreate(**{field: -1})


@pytest.mark.parametrize("schema", [InventoryCreate, InventoryUpdate])
def test_inventory_payload_rejects_quantity_above_operational_ceiling(schema) -> None:
    with pytest.raises(ValidationError):
        schema(quantity=1_000_000_001)


def test_quantity_policy_reports_a_specific_limit_error() -> None:
    assert validate_product_quantity(1_000_000_000) == 1_000_000_000
    with pytest.raises(ValueError, match=PRODUCT_QUANTITY_LIMIT_ERROR):
        validate_product_quantity(1_000_000_001)


def test_sync_batch_has_a_hard_operation_limit() -> None:
    operation = {"operation_id": "op", "entity": "product", "entity_id": 1, "operation": "DELETE"}
    with pytest.raises(ValidationError):
        SyncBatchRequest(operations=[{**operation, "operation_id": f"op-{index}"} for index in range(201)])


def test_subscription_expiry_uses_absolute_time_and_free_plan_does_not_expire() -> None:
    now = datetime.now(timezone.utc)
    assert subscription_expired("pro", now - timedelta(seconds=1))
    assert not subscription_expired("pro", now + timedelta(minutes=1))
    assert not subscription_expired("free", now - timedelta(days=1))
    assert subscription_expired("pro", (now - timedelta(seconds=1)).replace(tzinfo=None))


def test_builtin_device_limits_are_unlimited_by_default() -> None:
    assert all(plan["limits"]["devices"] is None for plan in PLAN_CATALOG.values())


def test_user_device_policy_precedence(monkeypatch) -> None:
    user = SimpleNamespace(is_admin=False, is_system_admin=False, role="USER", device_limit_mode="inherit", device_limit_override=None)
    assert plan_policy.effective_device_policy(None, user) == {"limit": None, "source": "plan", "mode": "unlimited"}
    user.device_limit_mode = "unlimited"
    assert plan_policy.effective_device_policy(None, user)["limit"] is None
    user.device_limit_mode = "limited"
    user.device_limit_override = 2
    assert plan_policy.can_add_device(None, user, 1)
    assert plan_policy.can_add_device(None, user, 200)


def test_role_changes_keep_legacy_admin_flag_synchronized() -> None:
    user = SimpleNamespace(role="USER", is_admin=False, is_system_admin=False)
    assert not has_permission(user, Permission.USERS_MANAGE)
    set_role(user, RoleId.ADMIN)
    assert user.role == "ADMIN"
    assert user.is_admin is True
    assert has_permission(user, Permission.CATALOG_MANAGE)
    set_role(user, RoleId.USER)
    assert user.is_admin is False


def test_industry_tool_policy_preserves_existing_availability_and_rejects_unknown_ids() -> None:
    assert normalize_tool_policy(None) == DEFAULT_TOOL_POLICY
    assert normalize_tool_policy({"export": False})["export"] is False
    assert normalize_tool_policy({"export": False})["catalog"] is True
    with pytest.raises(ValueError, match="UNKNOWN_TOOL_ID"):
        normalize_tool_policy({"future-tool": True})


def test_demo_reset_requires_explicit_confirmation() -> None:
    with pytest.raises(RuntimeError, match="CONFIRMATION_REQUIRED"):
        _assert_safe(1, "wrong")


def test_reference_manifest_sealing_is_deterministic_and_self_verifying() -> None:
    first, first_hash = _sealed_manifest({"z": 1, "name": "قطعه", "a": [2, 1]})
    second, second_hash = _sealed_manifest({"a": [2, 1], "name": "قطعه", "z": 1})
    assert first == second
    assert first_hash == second_hash
    sealed = json.loads(first)
    assert sealed.pop("content_hash") == first_hash
    assert hashlib.sha256(_canonical_json(sealed)).hexdigest() == first_hash


def test_reference_storage_rejects_traversal_and_preserves_immutable_releases(tmp_path) -> None:
    storage = ReferenceAssetStorage(tmp_path)
    with pytest.raises(ValueError, match="REFERENCE_ASSET_KEY_INVALID"):
        storage.put_blob_if_absent("blobs/../outside.webp", b"unsafe")

    release_id = "00000000-0000-4000-8000-000000000001"
    files = {"index.json": b'{"version":1}', "families/parts.json": b'{"items":[]}'}
    assert storage.publish_release(release_id, files) == f"releases/{release_id}"
    assert storage.publish_release(release_id, files) == f"releases/{release_id}"
    with pytest.raises(ValueError, match="CATALOG_RELEASE_IMMUTABILITY_VIOLATION"):
        storage.publish_release(release_id, {**files, "index.json": b'{"version":2}'})

    blob = b"trusted reference bytes"
    digest = hashlib.sha256(blob).hexdigest()
    key = f"blobs/{digest[:2]}/{digest}.webp"
    storage.put_blob_if_absent(key, blob)
    assert storage.verified_blob(key, digest, len(blob)).read_bytes() == blob
    storage.path_for(key).write_bytes(b"tampered")
    with pytest.raises(ValueError, match="REFERENCE_ASSET_INTEGRITY_VIOLATION"):
        storage.verified_blob(key, digest, len(blob))
    with pytest.raises(ValueError, match="REFERENCE_ASSET_IMMUTABILITY_VIOLATION"):
        storage.put_blob_if_absent(key, blob)


def test_server_exports_use_fixed_jalali_datetime_shape() -> None:
    value = format_jalali_datetime(datetime(2025, 1, 1, 0, 0, tzinfo=timezone.utc))
    assert value == "۱۴۰۳/۱۰/۱۲ ۰۳:۳۰"
