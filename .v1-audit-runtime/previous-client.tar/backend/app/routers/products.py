import uuid
from pathlib import Path
from typing import Annotated, Literal

from fastapi import APIRouter, File, Form, HTTPException, UploadFile, status
from sqlalchemy import func, select

from ..config import settings
from ..deps import CurrentProductCreator, CurrentProductDeleter, CurrentProductReader, DbSession, require_capability
from ..services.store_authorization import StorePermission, require_store_permission, project_inventory_item
from ..models import BarcodeReservation, CatalogProduct, Category, InventoryItem, ProductBarcode, Store
from sqlalchemy.orm import joinedload
from ..schemas import InventoryOut, PaginatedInventory, InventoryStats, PaginationMeta
from ..services.subscription_service import entitlement_for_user, locked_inventory_capacity
from ..services.authorization_service import is_admin
from ..inventory_policy import MAX_PRODUCT_QUANTITY
from ..services.taxonomy_service import (
    TAXONOMY_VERSION,
    issue_internal_barcode,
    validate_category_for_new_intent,
)

router = APIRouter(prefix="/products", tags=["products"])

_ALLOWED_IMAGE_TYPES = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/jpg": ".jpg",
    "image/webp": ".webp",
    "image/avif": ".avif",
    "image/gif": ".gif",
}
MAX_FILE_SIZE = 5 * 1024 * 1024

SortOption = Literal["newest", "price_desc", "price_asc", "name"]


def _get_owned_product(db: DbSession, product_id: int, store_id: int) -> InventoryItem:
    product = db.get(InventoryItem, product_id)
    if product is None or product.store_id != store_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="محصول یافت نشد"
        )
    return product


def _validate_category(db: DbSession, category_id: int | None, store_id: int) -> None:
    if category_id is None:
        return
    category = db.get(Category, category_id)
    if category is None or category.store_id != store_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="دسته بندی نامعتبر است"
        )


async def _save_image(image: UploadFile) -> str:
    ext = _ALLOWED_IMAGE_TYPES.get(image.content_type or "")
    if ext is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="فرمت تصویر پشتیبانی نمی شود",
        )
    filename = f"{uuid.uuid4().hex}{ext}"
    dest = settings.UPLOAD_DIR / filename
    content = await image.read()
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=400,
            detail="حجم فایل بیش از حد مجاز است"
        )
    dest.write_bytes(content)
    return f"/uploads/{filename}"


def _delete_image(image_url: str | None) -> None:
    if not image_url or not image_url.startswith("/uploads/"):
        return
    path = settings.UPLOAD_DIR / Path(image_url).name
    path.unlink(missing_ok=True)


def _validated_packaging(
    is_packaged: bool,
    pack_size: int | None,
) -> tuple[bool, int | None]:
    if not is_packaged:
        return False, None
    if pack_size is None or isinstance(pack_size, bool) or pack_size < 1:
        raise HTTPException(status_code=422, detail="PACK_SIZE_REQUIRED")
    return True, pack_size


@router.get("", response_model=PaginatedInventory)
def list_products(
    current_user: CurrentProductReader,
    db: DbSession,
    search: str | None = None,
    sort: SortOption = "newest",
    category_id: int | None = None,
    status_filter: Literal["in_stock","low_stock","out_of_stock"] | None = None,
    page: int = 1,
    limit: int = 10,
) -> PaginatedInventory:
    stmt = select(InventoryItem).options(joinedload(InventoryItem.catalog_product)).where(InventoryItem.store_id == current_user.store_id)

    if search:
        stmt = stmt.join(CatalogProduct).where(
            (CatalogProduct.name.ilike(f"%{search}%")) |
            (InventoryItem.custom_label.ilike(f"%{search}%"))
        )
    if category_id is not None:
        stmt = stmt.where(InventoryItem.category_id == category_id)

    products = list(db.scalars(stmt))

    if status_filter:
        products = [p for p in products if p.status == status_filter]

    products.sort(
        key=lambda p: {
            "newest": p.created_at.timestamp(),
            "price_desc": p.price,
            "price_asc": p.price,
            "name": (p.custom_label or p.catalog_product.name).lower(),
        }[sort],
        reverse=sort in ["newest", "price_desc"],
    )

    total = len(products)

    start = (page - 1) * limit
    end = start + limit

    paginated = products[start:end]

    return PaginatedInventory(
    items=[project_inventory_item(db, current_user, item) for item in paginated],
    meta=PaginationMeta(
        total=total,
        page=page,
        limit=limit,
    ),
    )


@router.post("", response_model=InventoryOut, status_code=status.HTTP_201_CREATED)
async def create_product(
    current_user: CurrentProductCreator,
    db: DbSession,
    name: Annotated[str, Form(min_length=1)],
    quantity: Annotated[int, Form(ge=0, le=MAX_PRODUCT_QUANTITY)] = 0,
    price: Annotated[int, Form(ge=0)] = 0,
    sale_price: Annotated[int | None, Form(ge=0)] = None,
    purchase_price: Annotated[int | None, Form(ge=0)] = None,
    description: Annotated[str | None, Form()] = None,
    unit: Annotated[str | None, Form()] = None,
    category_id: Annotated[int | None, Form()] = None,
    low_stock_threshold: Annotated[int, Form(ge=0)] = 0,
    low_stock_alert: Annotated[bool, Form()] = False,
    is_packaged: Annotated[bool, Form()] = False,
    pack_size: Annotated[int | None, Form(ge=1)] = None,
    image: Annotated[UploadFile | None, File()] = None,
) -> InventoryItem:
    require_capability(db, current_user, "inventory.write")
    if purchase_price is not None:
        require_store_permission(db, current_user, StorePermission.PURCHASE_PRICE_CHANGE)
    # Serialize first use against taxonomy adoption/sector selection. Without
    # this lock an empty store could adopt one sector while a concurrent create
    # commits under the previous policy.
    store = db.scalar(
        select(Store)
        .where(Store.id == current_user.store_id)
        .with_for_update()
    )
    if store is None:
        raise HTTPException(status_code=404, detail="STORE_NOT_FOUND")
    category = validate_category_for_new_intent(db, store, category_id)
    is_packaged, pack_size = _validated_packaging(is_packaged, pack_size)

    limit = None if is_admin(current_user) else locked_inventory_capacity(db, current_user)
    count = db.scalar(select(func.count(InventoryItem.id)).where(InventoryItem.store_id == current_user.store_id)) or 0
    if limit is not None and count >= limit:
        raise HTTPException(status_code=403, detail="INVENTORY_LIMIT_REACHED")

    image_url = await _save_image(image) if image is not None else None

    if current_user.industry_id is None:
        raise HTTPException(status_code=400, detail="INDUSTRY_REQUIRED")
    catalog = CatalogProduct(
        industry_id=current_user.industry_id,
        name=name,
        description=description,
        is_packaged=is_packaged,
        pack_size=pack_size,
        is_shared=False,
    )
    db.add(catalog)
    db.flush()
    product = InventoryItem(
        store_id=current_user.store_id,
        catalog_product_id=catalog.id,
        custom_label=name,
        note=description,
        quantity=quantity,
        price=sale_price if sale_price is not None else price,
        sale_price=sale_price if sale_price is not None else price,
        purchase_price=purchase_price,
        low_stock_threshold=low_stock_threshold,
        low_stock_alert=low_stock_alert,
        category_id=category_id,
        image_url=image_url,
        user_id=current_user.data_owner_id,
        is_catalog_backed=False,
    )
    db.add(product)
    db.flush()
    if store.taxonomy_version == TAXONOMY_VERSION:
        assert category is not None
        issue_internal_barcode(db, store, product, category)
    store.has_historical_inventory_usage = True
    db.commit()
    db.refresh(product)
    return project_inventory_item(db, current_user, product)


@router.patch("/{product_id}", response_model=InventoryOut)
async def update_product(
    product_id: int,
    current_user: CurrentProductReader,
    db: DbSession,
    name: Annotated[str | None, Form()] = None,
    quantity: Annotated[int | None, Form(ge=0, le=MAX_PRODUCT_QUANTITY)] = None,
    price: Annotated[int | None, Form(ge=0)] = None,
    sale_price: Annotated[int | None, Form(ge=0)] = None,
    purchase_price: Annotated[int | None, Form(ge=0)] = None,
    description: Annotated[str | None, Form()] = None,
    unit: Annotated[str | None, Form()] = None,
    category_id: Annotated[int | None, Form()] = None,
    low_stock_threshold: Annotated[int | None, Form(ge=0)] = None,
    low_stock_alert: Annotated[bool | None, Form()] = None,
    is_packaged: Annotated[bool | None, Form()] = None,
    pack_size: Annotated[int | None, Form(ge=1)] = None,
    image: Annotated[UploadFile | None, File()] = None,
    remove_image: Annotated[bool, Form()] = False,
) -> InventoryItem:
    from ..services.store_mode_policy import require_direct_mutation_allowed
    require_direct_mutation_allowed(db, current_user)
    require_capability(db, current_user, "inventory.write")
    detail_fields = (name, description, unit, category_id, low_stock_threshold, low_stock_alert, is_packaged, pack_size, image)
    if remove_image or any(value is not None for value in detail_fields):
        require_store_permission(db, current_user, StorePermission.PRODUCTS_EDIT)
    if quantity is not None:
        require_store_permission(db, current_user, StorePermission.QUANTITY_CHANGE)
    if price is not None or sale_price is not None:
        require_store_permission(db, current_user, StorePermission.SALE_PRICE_CHANGE)
    if purchase_price is not None:
        require_store_permission(db, current_user, StorePermission.PURCHASE_PRICE_CHANGE)
    product = _get_owned_product(db, product_id, current_user.store_id)
    store = db.get(Store, current_user.store_id)
    if store is None:
        raise HTTPException(status_code=404, detail="STORE_NOT_FOUND")

    if is_packaged is not None or pack_size is not None:
        if product.catalog_product.is_shared:
            raise HTTPException(status_code=409, detail="CATALOG_PACKAGING_ADMIN_CONTROLLED")
        effective_packaged = (
            is_packaged if is_packaged is not None else product.catalog_product.is_packaged
        )
        effective_pack_size = (
            pack_size if pack_size is not None else product.catalog_product.pack_size
        )
        effective_packaged, effective_pack_size = _validated_packaging(
            effective_packaged,
            effective_pack_size,
        )
        product.catalog_product.is_packaged = effective_packaged
        product.catalog_product.pack_size = effective_pack_size

    if category_id is not None:
        validate_category_for_new_intent(db, store, category_id)
        if store.taxonomy_version == TAXONOMY_VERSION and category_id != product.category_id:
            raise HTTPException(status_code=409, detail="CATEGORY_CHANGE_REQUIRES_PREVIEW")

    updates = {
        "custom_label": name,
        "quantity": quantity,
        "price": price,
        "note": description,
        "category_id": category_id,
        "low_stock_threshold": low_stock_threshold,
        "low_stock_alert": low_stock_alert,
    }
    for field, value in updates.items():
        if value is not None:
            setattr(product, field, value)
    effective_sale_price = sale_price if sale_price is not None else price
    if effective_sale_price is not None:
        product.sale_price = effective_sale_price
        product.price = effective_sale_price
    if purchase_price is not None:
        product.purchase_price = purchase_price

    if image is not None:
        _delete_image(product.image_url)
        product.image_url = await _save_image(image)
    elif remove_image:
        _delete_image(product.image_url)
        product.image_url = None

    db.commit()
    db.refresh(product)
    return project_inventory_item(db, current_user, product)


@router.delete("/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_product(
    product_id: int, current_user: CurrentProductDeleter, db: DbSession
) -> None:
    product = _get_owned_product(db, product_id, current_user.store_id)
    if product.is_catalog_backed:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="CATALOG_BACKED_PRODUCT_DELETE_FORBIDDEN",
        )
    private_catalog = (
        product.catalog_product if not product.catalog_product.is_shared else None
    )
    reservations = list(db.scalars(
        select(BarcodeReservation).where(
            BarcodeReservation.store_id == current_user.store_id,
            BarcodeReservation.target_type == "product",
            BarcodeReservation.target_id == product.id,
        )
    ))
    for reservation in reservations:
        reservation.status = "deleted"
        reservation.retired_at = func.now()
    for barcode in db.scalars(select(ProductBarcode).where(
        ProductBarcode.store_id == current_user.store_id,
        ProductBarcode.product_id == product.id,
    )):
        barcode.is_active = False
        barcode.is_default = False
        barcode.lifecycle_status = "deleted"
    _delete_image(product.image_url)
    db.delete(product)
    db.flush()
    if private_catalog is not None:
        db.delete(private_catalog)
    db.commit()


@router.get("/stats", response_model=InventoryStats)
def product_stats(
    current_user: CurrentProductReader,
    db: DbSession,
) -> InventoryStats:
    products = list(
        db.scalars(
            select(InventoryItem).where(InventoryItem.store_id == current_user.store_id)
        )
    )

    total_products = len(products)
    total_quantity = sum(p.quantity for p in products)
    inventory_value = sum(p.price * p.quantity for p in products)
    low_stock_count = sum(1 for p in products if p.status == "low_stock")
    out_of_stock_count = sum(1 for p in products if p.status == "out_of_stock")

    most_expensive = max(products, key=lambda p: p.price, default=None)
    cheapest = min(products, key=lambda p: p.price, default=None)

    return InventoryStats(
        total_items=total_products,
        total_quantity=total_quantity,
        inventory_value=inventory_value,
        low_stock_count=low_stock_count,
        out_of_stock_count=out_of_stock_count,
        most_expensive_price=most_expensive.price if most_expensive else None,
        cheapest_price=cheapest.price if cheapest else None,
    )


@router.get("/alerts/low-stock", response_model=list[InventoryOut])
def low_stock_alerts(
    current_user: CurrentProductReader,
    db: DbSession,
) -> list[InventoryItem]:
    products = list(
        db.scalars(
            select(InventoryItem).where(InventoryItem.store_id == current_user.store_id)
        )
    )

    alerts = [
        p
        for p in products
        if p.low_stock_alert
        and p.low_stock_threshold > 0
        and p.quantity <= p.low_stock_threshold
    ]

    return [project_inventory_item(db, current_user, item) for item in alerts]


@router.get("/alerts/count")
def alerts_count(
    current_user: CurrentProductReader,
    db: DbSession,
):
    products = list(
        db.scalars(
            select(InventoryItem).where(InventoryItem.store_id == current_user.store_id)
        )
    )

    count = sum(
        1
        for p in products
        if p.low_stock_alert
        and p.low_stock_threshold > 0
        and p.quantity <= p.low_stock_threshold
    )

    return {"count": count}


@router.get("/{product_id}", response_model=InventoryOut)
def get_product(
    product_id: int, current_user: CurrentProductReader, db: DbSession
) -> dict:
    return project_inventory_item(db, current_user, _get_owned_product(db, product_id, current_user.store_id))
