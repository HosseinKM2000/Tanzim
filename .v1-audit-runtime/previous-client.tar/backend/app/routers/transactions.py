from fastapi import APIRouter, HTTPException, status
from sqlalchemy import select

from ..deps import CurrentProductReader, CurrentQuantityWriter, DbSession
from ..models import InventoryItem, InventoryTransaction
from ..schemas import TransactionCreate, TransactionOut
from ..inventory_policy import MAX_PRODUCT_QUANTITY, PRODUCT_QUANTITY_LIMIT_ERROR

router = APIRouter(prefix="/transactions", tags=["transactions"])


def _get_owned_product(
    db: DbSession,
    product_id: int,
    store_id: int,
) -> InventoryItem:
    product = db.get(InventoryItem, product_id)

    if product is None or product.store_id != store_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="محصول یافت نشد",
        )

    return product


@router.post(
    "/products/{product_id}",
    response_model=TransactionOut,
    status_code=status.HTTP_201_CREATED,
)
def create_transaction(
    product_id: int,
    payload: TransactionCreate,
    current_user: CurrentQuantityWriter,
    db: DbSession,
) -> InventoryTransaction:

    product = _get_owned_product(db, product_id, current_user.store_id)

    # validation
    if payload.type == "stock_out" and payload.quantity > product.quantity:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="موجودی کافی نیست",
        )
    if payload.type == "stock_in" and product.quantity + payload.quantity > MAX_PRODUCT_QUANTITY:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=PRODUCT_QUANTITY_LIMIT_ERROR,
        )

    before_quantity = product.quantity

    # update stock
    if payload.type == "stock_in":
        product.quantity += payload.quantity
    else:
        product.quantity -= payload.quantity

    after_quantity = product.quantity

    # create transaction
    transaction = InventoryTransaction(
        store_id=current_user.store_id,
        actor_user_id=current_user.id,
        inventory_item_id=product.id,
        user_id=current_user.data_owner_id,
        type=payload.type,
        quantity=payload.quantity,
        before_quantity=before_quantity,
        after_quantity=after_quantity,
        note=payload.note,
    )

    db.add(transaction)
    db.commit()
    db.refresh(transaction)

    return transaction


@router.get(
    "/products/{product_id}",
    response_model=list[TransactionOut],
)
def product_transactions(
    product_id: int,
    current_user: CurrentProductReader,
    db: DbSession,
) -> list[InventoryTransaction]:

    _get_owned_product(db, product_id, current_user.store_id)

    stmt = (
        select(InventoryTransaction)
        .where(
            InventoryTransaction.inventory_item_id == product_id,
            InventoryTransaction.store_id == current_user.store_id,
        )
        .order_by(
            InventoryTransaction.created_at.desc(),
            InventoryTransaction.id.desc(),
        )
    )

    return list(db.scalars(stmt))


@router.get("", response_model=list[TransactionOut])
def all_transactions(
    current_user: CurrentProductReader,
    db: DbSession,
) -> list[InventoryTransaction]:

    stmt = (
        select(InventoryTransaction)
        .where(InventoryTransaction.store_id == current_user.store_id)
        .order_by(
            InventoryTransaction.created_at.desc(),
            InventoryTransaction.id.desc(),
        )
    )

    return list(db.scalars(stmt))
