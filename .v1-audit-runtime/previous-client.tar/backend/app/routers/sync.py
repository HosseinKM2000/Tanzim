import json
import logging
import hashlib
import hmac
import uuid
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated

from fastapi import APIRouter, File, Form, Header, HTTPException, Request, UploadFile
from sqlalchemy import func, select
from sqlalchemy.orm import joinedload, selectinload

from ..config import settings
from ..inventory_policy import MAX_PRODUCT_QUANTITY, PRODUCT_QUANTITY_LIMIT_ERROR, validate_product_quantity
from ..deps import CurrentProductReader, DbSession
from ..models import (
    BarcodeReservation,
    CatalogProduct,
    Category,
    Industry,
    InventoryItem,
    InventoryMovement,
    InventoryTransaction,
    Invoice,
    Label,
    MediaAsset,
    ProductBarcode,
    ReferenceSector,
    SyncChange,
    SyncOperation,
    Store,
    User,
)
from ..services.subscription_service import entitlement_for_user, locked_inventory_capacity
from ..services.tool_policy import tool_allowed
from ..services.authorization_service import is_admin
from ..services.activity_service import record_store_activity
from ..services.store_authorization import StorePermission, effective_permissions
from ..services.store_service import active_store_context
from ..services.store_mode_policy import validate_sync_acceptance
from ..services.invoice_service import cancel_invoice, post_invoice
from ..services.taxonomy_service import (
    TAXONOMY_VERSION,
    custom_category_code,
    issue_internal_barcode,
    reserve_external_barcode,
    validate_category_for_new_intent,
)


logger = logging.getLogger("tanzim.sync")
_SAFE_DIAGNOSTIC_CODE = re.compile(r"^[A-Z][A-Z0-9_.:-]{2,127}$")
from ..schemas import (
    InventoryOut,
    InventoryMovementOut,
    BarcodeOut,
    BarcodeSnapshot,
    CategoryOut,
    SyncBatchRequest,
    SyncBatchResponse,
    SyncChangeOut,
    SyncChangesResponse,
    SyncOperationIn,
    SyncOperationResult,
)

router = APIRouter(prefix="/sync", tags=["sync"])

_IMAGE_EXTENSIONS = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/webp": ".webp",
    "image/avif": ".avif",
    "image/gif": ".gif",
}
_MAX_IMAGE_BYTES = 10 * 1024 * 1024
_MINIMUM_CLIENT_DATA_SCHEMA = 2


@router.get("/operations/{operation_id}", response_model=SyncOperationResult)
def recorded_operation_result(
    operation_id: str,
    current_user: CurrentProductReader,
    db: DbSession,
    client_data_schema: Annotated[int | None, Header(alias="X-Client-Data-Schema")] = None,
) -> SyncOperationResult:
    """Return only an already-recorded result; never apply an operation."""
    _require_store_aware_client(client_data_schema)
    previous = db.scalar(select(SyncOperation).where(
        SyncOperation.store_id == current_user.store_id,
        SyncOperation.actor_user_id == current_user.id,
        SyncOperation.operation_id == operation_id,
    ))
    if previous is None:
        raise HTTPException(status_code=404, detail="SYNC_OPERATION_NOT_RECORDED")
    result = SyncOperationResult.model_validate_json(previous.result_payload)
    permissions = effective_permissions(active_store_context(db, current_user))
    if isinstance(result.record, InventoryOut):
        raw_record = result.record.model_dump(mode="json")
    elif isinstance(result.record, dict):
        raw_record = result.record
    else:
        return result
    if "catalog_product_id" in raw_record:
        result.record = _project_record(raw_record, permissions, client_data_schema or 2)
    elif isinstance(raw_record.get("product"), dict):
        result.record = {
            **raw_record,
            "product": _project_record(raw_record["product"], permissions, client_data_schema or 2),
        }
    return result


def _activity_evidence(operation: SyncOperationIn, result: SyncOperationResult | None = None) -> dict[str, object] | None:
    """Keep only small business-facing hints; never mirror an operation payload."""
    payload = operation.payload or {}
    record = result.record if result is not None and isinstance(result.record, dict) else {}
    product = record.get("product") if isinstance(record.get("product"), dict) else record
    movement = record.get("movement") if isinstance(record.get("movement"), dict) else {}
    catalog = payload.get("catalog_product")
    if not isinstance(catalog, dict) and isinstance(product, dict):
        catalog = product.get("catalog_product")
    catalog_name = catalog.get("name") if isinstance(catalog, dict) else None
    name = next((value.strip() for value in (
        payload.get("custom_label"), payload.get("product_name"), payload.get("title"),
        payload.get("name"), product.get("custom_label") if isinstance(product, dict) else None, catalog_name,
    ) if isinstance(value, str) and value.strip()), None)
    evidence: dict[str, object] = {}
    if name is not None:
        evidence["name"] = name
    quantity = payload.get("quantity")
    if isinstance(quantity, int) and not isinstance(quantity, bool):
        evidence["quantity"] = quantity
    for source, destination in (("before_quantity", "before_quantity"), ("after_quantity", "quantity")):
        value = movement.get(source)
        if isinstance(value, int) and not isinstance(value, bool):
            evidence[destination] = value
    return evidence or None


async def _operation_fingerprint(
    operation: SyncOperationIn,
    image: UploadFile | None,
) -> str:
    semantic = operation.model_dump(mode="json")
    # Fields introduced with schema 0010 are omitted when absent so an exact
    # pre-migration request keeps its historical fingerprint after upgrade.
    if operation.execution_mode is None:
        semantic.pop("execution_mode", None)
    if operation.policy_version is None:
        semantic.pop("policy_version", None)
    if image is not None:
        content = await image.read()
        await image.seek(0)
        semantic["attached_image"] = {
            "content_type": image.content_type,
            "sha256": hashlib.sha256(content).hexdigest(),
        }
    canonical = json.dumps(
        semantic,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def _serialize_operation_submission(
    db: DbSession,
    store_id: int,
    actor_user_id: int,
    operation_id: str,
) -> None:
    """Serialize one tenant-scoped idempotency key for PostgreSQL writers."""
    if db.bind is None or db.bind.dialect.name != "postgresql":
        return
    digest = hashlib.sha256(
        f"{store_id}:{actor_user_id}:{operation_id}".encode("utf-8")
    ).digest()
    lock_key = int.from_bytes(digest[:8], byteorder="big", signed=True)
    db.execute(select(func.pg_advisory_xact_lock(lock_key)))


def _duplicate_result(
    previous: SyncOperation,
    operation: SyncOperationIn,
    fingerprint: str,
) -> SyncOperationResult:
    if previous.request_fingerprint is None:
        return SyncOperationResult(
            operation_id=operation.operation_id,
            status="fatal_error",
            entity_id=operation.entity_id,
            error="OPERATION_PAYLOAD_UNVERIFIED",
        )
    if not hmac.compare_digest(previous.request_fingerprint, fingerprint):
        return SyncOperationResult(
            operation_id=operation.operation_id,
            status="fatal_error",
            entity_id=operation.entity_id,
            error="OPERATION_PAYLOAD_MISMATCH",
        )
    return _result_from_json(previous.result_payload)


def _require_store_aware_client(value: int | None) -> None:
    if value is None or value < _MINIMUM_CLIENT_DATA_SCHEMA:
        raise HTTPException(status_code=426, detail="CLIENT_UPDATE_REQUIRED:STORE_WORKSPACE")


def _authorize_operation(
    db: DbSession,
    user: User,
    operation: SyncOperationIn,
    *,
    accepted_at: datetime,
) -> None:
    permissions = effective_permissions(active_store_context(db, user))
    required: set[str]
    if operation.entity == "barcode":
        required = {StorePermission.BARCODE_MANAGE.value}
    elif operation.entity == "inventory_movement":
        required = {StorePermission.BARCODE_LOOKUP.value, StorePermission.QUANTITY_CHANGE.value}
    elif operation.entity == "invoice":
        required = {StorePermission.INVOICES_VIEW.value}
        if operation.operation == "CREATE":
            required.add(StorePermission.INVOICES_POST.value)
            invoice_type = (operation.payload or {}).get("invoice_type")
        elif operation.operation == "UPDATE" and (operation.payload or {}).get("action") == "cancel":
            required.add(StorePermission.INVOICES_CANCEL.value)
            invoice_type = db.scalar(select(Invoice.invoice_type).where(
                Invoice.id == operation.entity_id,
                Invoice.store_id == user.store_id,
            ))
        else:
            raise ValueError("INVOICE_OPERATION_INVALID")
        if invoice_type == "purchase":
            required.add(StorePermission.PURCHASE_PRICE_VIEW.value)
        if invoice_type not in {"purchase", "sale"}:
            raise ValueError("INVOICE_TYPE_INVALID")
    elif operation.entity == "label":
        required = {StorePermission.LABELS_MANAGE.value}
    elif operation.entity == "category":
        required = {StorePermission.CATEGORIES_MANAGE.value}
    elif operation.entity != "product":
        raise ValueError("UNKNOWN_SYNC_ENTITY")
    elif operation.operation == "DELETE":
        required = {StorePermission.PRODUCTS_DELETE.value}
    elif operation.operation == "CREATE":
        required = {StorePermission.PRODUCTS_CREATE.value}
        if (operation.payload or {}).get("purchase_price") is not None:
            required.add(StorePermission.PURCHASE_PRICE_CHANGE.value)
    else:
        payload = operation.payload or {}
        required = set()
        if "quantity" in payload:
            required.add(StorePermission.QUANTITY_CHANGE.value)
        if "price" in payload or "sale_price" in payload:
            required.add(StorePermission.SALE_PRICE_CHANGE.value)
        if "purchase_price" in payload:
            required.add(StorePermission.PURCHASE_PRICE_CHANGE.value)
        if set(payload) - {"quantity", "price", "sale_price", "purchase_price", "price_missing"}:
            required.add(StorePermission.PRODUCTS_EDIT.value)
    missing = required - permissions
    if missing:
        raise ValueError(f"PERMISSION_REQUIRED:{sorted(missing)[0]}")
    entitlement = entitlement_for_user(db, user, as_of=accepted_at)
    capabilities = entitlement["capabilities"]
    if not capabilities.get("sync", False):
        if entitlement["status"] == "expired":
            raise ValueError("ENTITLEMENT_EXPIRED")
        raise ValueError("CAPABILITY_REQUIRED:sync")
    feature = (
        "barcode.manage" if operation.entity == "barcode"
        else "barcode.lookup" if operation.entity == "inventory_movement"
        else f"invoices.{invoice_type}" if operation.entity == "invoice"
        else "inventory.write"
    )
    if not capabilities.get(feature, False):
        if entitlement["status"] == "expired":
            raise ValueError("ENTITLEMENT_EXPIRED")
        raise ValueError(f"CAPABILITY_REQUIRED:{feature}")
    if not capabilities.get("inventory.write", False):
        if entitlement["status"] == "expired":
            raise ValueError("ENTITLEMENT_EXPIRED")
        raise ValueError("CAPABILITY_REQUIRED:inventory.write")


def _serialize(item: InventoryItem) -> dict:
    record = InventoryOut.model_validate(item).model_dump(mode="json")
    asset = item.media_asset
    if asset is not None:
        record.update({
            "media_version": asset.version,
            "media_content_sha256": asset.content_sha256,
            "media_byte_size": asset.byte_size,
            "media_preview_url": f"/api/media/{asset.id}/preview",
            "media_detail_url": f"/api/media/{asset.id}/detail",
        })
    sale_price = item.sale_price if item.sale_price is not None else None
    record.update({"sale_price": sale_price, "purchase_price": item.purchase_price, "price": sale_price or 0, "price_missing": sale_price is None})
    return record


def _project_record(record: dict | None, permissions: frozenset[str], client_schema: int) -> dict | None:
    if record is None:
        return None
    output = dict(record)
    if client_schema < 3:
        output.pop("sale_price", None)
        output.pop("purchase_price", None)
        output.pop("price_missing", None)
        return output
    if "sale_price" not in output and "price" in output:
        output["sale_price"] = None if output.get("price_missing") else output["price"]
    output["price_missing"] = output.get("sale_price") is None
    if StorePermission.PURCHASE_PRICE_VIEW.value not in permissions:
        output["purchase_price"] = None
    if StorePermission.SALE_PRICE_VIEW.value not in permissions:
        output.update({"sale_price": None, "price": 0, "price_missing": True})
    return output


def _result_from_json(value: str) -> SyncOperationResult:
    return SyncOperationResult.model_validate_json(value)


def _packaging_values(
    payload: dict,
    current_packaged: bool = False,
    current_pack_size: int | None = None,
) -> tuple[bool, int | None]:
    is_packaged = payload.get("is_packaged", current_packaged)
    pack_size = payload.get("pack_size", current_pack_size)
    if not isinstance(is_packaged, bool):
        raise ValueError("PACKAGING_FLAG_INVALID")
    if not is_packaged:
        return False, None
    if isinstance(pack_size, bool) or not isinstance(pack_size, int) or pack_size < 1:
        raise ValueError("PACK_SIZE_REQUIRED")
    return True, pack_size


def _catalog_for_operation(
    db: DbSession,
    user: User,
    operation: SyncOperationIn,
) -> CatalogProduct:
    payload = operation.payload or {}
    catalog_payload = payload.get("catalog_product") or {}
    catalog_id = catalog_payload.get("id")

    if isinstance(catalog_id, int) and catalog_id > 0:
        catalog = db.get(CatalogProduct, catalog_id)
        if (
            catalog is not None
            and catalog.is_shared
            and catalog.is_active
            and catalog.industry_id == user.industry_id
        ):
            return catalog
        raise ValueError("CATALOG_PRODUCT_NOT_AVAILABLE")

    if user.industry_id is None:
        raise ValueError("An industry is required before creating a product")

    name = catalog_payload.get("name") or payload.get("custom_label")
    if not isinstance(name, str) or not name.strip():
        raise ValueError("Product name is required")

    is_packaged, pack_size = _packaging_values(catalog_payload)
    catalog = CatalogProduct(
        industry_id=user.industry_id,
        name=name.strip(),
        description=catalog_payload.get("description"),
        brand=catalog_payload.get("brand"),
        is_packaged=is_packaged,
        pack_size=pack_size,
        is_shared=False,
    )
    db.add(catalog)
    db.flush()
    return catalog


def _apply_fields(
    db: DbSession,
    store_id: int,
    item: InventoryItem,
    payload: dict,
) -> None:
    catalog_payload = payload.get("catalog_product") or {}
    if not isinstance(catalog_payload, dict):
        raise ValueError("CATALOG_PRODUCT_INVALID")
    if (
        not item.catalog_product.is_shared
        and ("is_packaged" in catalog_payload or "pack_size" in catalog_payload)
    ):
        is_packaged, pack_size = _packaging_values(
            catalog_payload,
            item.catalog_product.is_packaged,
            item.catalog_product.pack_size,
        )
        item.catalog_product.is_packaged = is_packaged
        item.catalog_product.pack_size = pack_size

    for field in ("quantity", "low_stock_threshold"):
        if field in payload:
            value = payload[field]
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"{field} must be a non-negative integer")
            if field == "quantity":
                validate_product_quantity(value)
            setattr(item, field, value)

    if "sale_price" in payload or "price" in payload:
        value = payload.get("sale_price") if "sale_price" in payload else payload.get("price")
        if value is not None and (isinstance(value, bool) or not isinstance(value, int) or value < 0):
            raise ValueError("sale_price must be a non-negative integer or null")
        item.sale_price = value
        item.price = value or 0
    if "purchase_price" in payload:
        value = payload["purchase_price"]
        if value is not None and (isinstance(value, bool) or not isinstance(value, int) or value < 0):
            raise ValueError("purchase_price must be a non-negative integer or null")
        item.purchase_price = value

    for field in ("low_stock_alert", "is_hidden"):
        if field in payload:
            value = payload[field]
            if not isinstance(value, bool):
                raise ValueError(f"{field} must be a boolean")
            setattr(item, field, value)

    for field in ("custom_label", "note"):
        if field in payload:
            value = payload[field]
            if value is not None and not isinstance(value, str):
                raise ValueError(f"{field} must be text or null")
            setattr(item, field, value)

    if "category_id" in payload:
        value = payload["category_id"]
        if value is not None and (isinstance(value, bool) or not isinstance(value, int)):
            raise ValueError("category_id must be an integer or null")
        if value is not None:
            category = db.scalar(
                select(Category).where(
                    Category.id == value,
                    Category.store_id == store_id,
                )
            )
            if category is None:
                raise ValueError("CATEGORY_NOT_AVAILABLE")
        item.category_id = value

    if "label_ids" in payload:
        values = payload["label_ids"]
        if not isinstance(values, list) or any(isinstance(value, bool) or not isinstance(value, int) for value in values):
            raise ValueError("label_ids must be an integer list")
        unique_ids = list(dict.fromkeys(values))
        labels = list(db.scalars(select(Label).where(
            Label.store_id == store_id, Label.id.in_(unique_ids)
        ))) if unique_ids else []
        if len(labels) != len(unique_ids):
            raise ValueError("LABEL_NOT_AVAILABLE")
        item.labels = labels


def _normalize_label(value: str) -> tuple[str, str]:
    import unicodedata
    name = " ".join(unicodedata.normalize("NFC", value).strip().split())
    if not name or len(name) > 60:
        raise ValueError("LABEL_NAME_INVALID")
    return name, name.casefold()


def _apply_label(db: DbSession, user: User, operation: SyncOperationIn) -> SyncOperationResult:
    label = db.scalar(select(Label).where(Label.id == operation.entity_id, Label.store_id == user.store_id))
    if operation.operation == "DELETE":
        if label is not None:
            affected = list(label.inventory_items)
            for item in affected:
                item.labels = [existing for existing in item.labels if existing.id != label.id]
            db.flush()
            for item in affected:
                _record_change(db, user, item.id, "UPSERT", _serialize(item))
            db.delete(label)
        return SyncOperationResult(operation_id=operation.operation_id, status="applied", entity_id=operation.entity_id)
    payload = operation.payload or {}
    raw_name = payload.get("name")
    if not isinstance(raw_name, str):
        raise ValueError("LABEL_NAME_INVALID")
    name, normalized = _normalize_label(raw_name)
    duplicate = db.scalar(select(Label).where(
        Label.store_id == user.store_id, Label.normalized_name == normalized, Label.id != operation.entity_id
    ))
    if duplicate is not None:
        raise ValueError("LABEL_NAME_EXISTS")
    if label is None:
        if operation.operation == "UPDATE":
            raise ValueError("LABEL_NOT_FOUND")
        label = Label(
            id=operation.entity_id, store_id=user.store_id,
            user_id=user.data_owner_id, name=name, normalized_name=normalized,
        )
        db.add(label)
    else:
        if operation.base_version is not None and label.version != operation.base_version:
            return SyncOperationResult(operation_id=operation.operation_id, status="conflict", entity_id=label.id, error="Server record has a newer version")
        label.name = name
        label.normalized_name = normalized
        label.version += 1
    db.flush()
    return SyncOperationResult(
        operation_id=operation.operation_id, status="applied", entity_id=label.id,
        record={"id": label.id, "name": label.name, "normalized_name": label.normalized_name,
                "version": label.version, "created_at": label.created_at, "updated_at": label.updated_at},
    )


def _apply_category(db: DbSession, user: User, operation: SyncOperationIn) -> SyncOperationResult:
    category = db.scalar(select(Category).where(Category.id == operation.entity_id, Category.store_id == user.store_id))
    created = category is None
    if operation.operation == "DELETE":
        if category is not None:
            if category.origin == "system":
                raise ValueError("SYSTEM_CATEGORY_IMMUTABLE")
            category.is_active = False
            category.version += 1
        return SyncOperationResult(operation_id=operation.operation_id, status="applied", entity_id=operation.entity_id)
    payload = operation.payload or {}
    name = payload.get("name")
    if not isinstance(name, str) or not name.strip() or len(name.strip()) > 120:
        raise ValueError("CATEGORY_NAME_INVALID")
    duplicate = db.scalar(select(Category).where(
        Category.store_id == user.store_id, Category.name == name.strip(), Category.id != operation.entity_id
    ))
    if duplicate is not None:
        raise ValueError("CATEGORY_NAME_EXISTS")
    if category is None:
        if operation.operation == "UPDATE":
            raise ValueError("CATEGORY_NOT_FOUND")
        store = db.get(Store, user.store_id)
        if store is None:
            raise ValueError("STORE_NOT_FOUND")
        adopted = store.taxonomy_version == TAXONOMY_VERSION
        sector = db.get(Industry, store.industry_id) if adopted and store.industry_id is not None else None
        if adopted and (sector is None or not sector.sector_code):
            raise ValueError("STORE_SECTOR_MAPPING_INVALID")
        if adopted and sector.reference_sector_id is not None:
            reference_sector = db.get(ReferenceSector, sector.reference_sector_id)
            if reference_sector is None or not reference_sector.custom_categories_allowed:
                raise ValueError("CUSTOM_CATEGORY_FORBIDDEN_FOR_SECTOR")
        requested_code = payload.get("code")
        if adopted and (not isinstance(requested_code, str) or re.fullmatch(r"C[A-Z0-9]{13,23}", requested_code) is None):
            raise ValueError("CUSTOM_CATEGORY_CODE_INVALID")
        if adopted and payload.get("sector_code") != sector.sector_code:
            raise ValueError("CATEGORY_SECTOR_MISMATCH")
        category = Category(
            id=operation.entity_id, store_id=user.store_id,
            user_id=user.data_owner_id, name=name.strip(),
            code=requested_code if adopted else None,
            sector_code=sector.sector_code if sector else None,
            origin="custom" if adopted else "legacy",
            approval_status="approved" if adopted else "legacy",
            is_active=True, taxonomy_version=TAXONOMY_VERSION if adopted else None,
        )
        db.add(category)
    elif category.origin == "system":
        raise ValueError("SYSTEM_CATEGORY_IMMUTABLE")
    category.name = name.strip()
    description = payload.get("description")
    if description is not None and not isinstance(description, str):
        raise ValueError("CATEGORY_DESCRIPTION_INVALID")
    category.description = description
    if "is_active" in payload:
        if category.origin != "custom" or not isinstance(payload["is_active"], bool):
            raise ValueError("CATEGORY_LIFECYCLE_INVALID")
        category.is_active = payload["is_active"]
    if not created:
        category.version += 1
    db.flush()
    return SyncOperationResult(
        operation_id=operation.operation_id, status="applied", entity_id=category.id,
        record=CategoryOut.model_validate(category).model_dump(mode="json"),
    )


_CODE128_ASCII = re.compile(r"^[\x20-\x7E]+$")
_BARCODE_LENGTHS = {"ean13": 13, "ean8": 8, "upca": 12, "upce": 8}


def _numeric_checksum(value: str) -> bool:
    digits = [int(value) for value in value]
    check = digits.pop()
    total = sum(digit * (3 if position % 2 == 0 else 1) for position, digit in enumerate(reversed(digits)))
    return (10 - total % 10) % 10 == check


def _expand_upce(value: str) -> str | None:
    if len(value) != 8 or not value.isdigit() or value[0] not in {"0", "1"}:
        return None
    number_system, body, check = value[0], value[1:7], value[7]
    last = body[5]
    if last in "012":
        return f"{number_system}{body[:2]}{last}0000{body[2:5]}{check}"
    if last == "3":
        return f"{number_system}{body[:3]}00000{body[3:5]}{check}"
    if last == "4":
        return f"{number_system}{body[:4]}00000{body[4]}{check}"
    return f"{number_system}{body[:5]}0000{last}{check}"


def _barcode_candidates(value: str, symbology: str) -> set[str]:
    values = {value}
    if symbology == "upca":
        values.add(f"0{value}")
    elif symbology == "ean13" and value.startswith("0") and _numeric_checksum(value[1:]):
        values.add(value[1:])
    return values


def _validate_barcode(value: object, symbology: object) -> tuple[str, str]:
    if not isinstance(value, str) or not value or len(value) > 64:
        raise ValueError("BARCODE_VALUE_INVALID")
    if not isinstance(symbology, str) or symbology not in {"code128", "datamatrix", "ean13", "ean8", "upca", "upce", "unknown"}:
        raise ValueError("BARCODE_SYMBOLOGY_INVALID")
    if symbology in {"code128", "datamatrix", "unknown"}:
        if _CODE128_ASCII.fullmatch(value) is None:
            raise ValueError("BARCODE_CHARSET_INVALID")
    elif not value.isascii() or not value.isdigit() or len(value) != _BARCODE_LENGTHS[symbology]:
        raise ValueError("BARCODE_FORMAT_INVALID")
    else:
        checksum_value = _expand_upce(value) if symbology == "upce" else value
        if checksum_value is None or not _numeric_checksum(checksum_value):
            raise ValueError("BARCODE_CHECKSUM_INVALID")
    return value, symbology


def _create_embedded_external_barcodes(
    db: DbSession,
    *,
    store: Store,
    product: InventoryItem,
    category: Category | None,
    payload: object,
) -> None:
    if not isinstance(payload, list) or not payload or len(payload) > 20:
        raise ValueError("EMBEDDED_BARCODES_INVALID")
    seen_ids: set[int] = set()
    seen_values: set[str] = set()
    for index, raw in enumerate(payload):
        if not isinstance(raw, dict):
            raise ValueError("EMBEDDED_BARCODE_INVALID")
        barcode_id = raw.get("id")
        if isinstance(barcode_id, bool) or not isinstance(barcode_id, int) or barcode_id <= 0 or barcode_id in seen_ids:
            raise ValueError("EMBEDDED_BARCODE_ID_INVALID")
        if raw.get("source") != "manufacturer":
            raise ValueError("EMBEDDED_BARCODE_SOURCE_INVALID")
        value, symbology = _validate_barcode(raw.get("value"), raw.get("symbology", "code128"))
        if value in seen_values:
            raise ValueError("BARCODE_ALREADY_RESERVED")
        meaning = raw.get("meaning")
        scan_quantity = raw.get("scan_quantity")
        if meaning not in {"unit", "package"}:
            raise ValueError("BARCODE_MEANING_INVALID")
        if isinstance(scan_quantity, bool) or not isinstance(scan_quantity, int) or scan_quantity < 1:
            raise ValueError("BARCODE_SCAN_QUANTITY_INVALID")
        if meaning == "unit" and scan_quantity != 1:
            raise ValueError("UNIT_BARCODE_QUANTITY_INVALID")
        reservation = reserve_external_barcode(
            db,
            store_id=store.id,
            product_id=product.id,
            value=value,
            category_reference_key=category.reference_key if category else None,
        )
        db.add(ProductBarcode(
            id=barcode_id,
            store_id=store.id,
            product_id=product.id,
            value=value,
            source="manufacturer",
            symbology=symbology,
            meaning=meaning,
            scan_quantity=scan_quantity,
            is_active=True,
            is_default=index == 0,
            lifecycle_status="active",
            reservation_id=reservation.id,
            category_reference_key=category.reference_key if category else None,
        ))
        seen_ids.add(barcode_id)
        seen_values.add(value)


def _apply_barcode(db: DbSession, user: User, operation: SyncOperationIn) -> SyncOperationResult:
    barcode = db.scalar(select(ProductBarcode).where(
        ProductBarcode.id == operation.entity_id,
        ProductBarcode.store_id == user.store_id,
    ))
    if operation.operation == "DELETE":
        if barcode is not None:
            barcode.is_active = False
            barcode.is_default = False
            barcode.lifecycle_status = "retired"
            barcode.version += 1
            reservation = db.get(BarcodeReservation, barcode.reservation_id)
            if reservation is not None:
                reservation.status = "retired"
                reservation.retired_at = datetime.now(timezone.utc)
        return SyncOperationResult(operation_id=operation.operation_id, status="applied", entity_id=operation.entity_id)

    payload = operation.payload or {}
    value, symbology = _validate_barcode(payload.get("value"), payload.get("symbology", "code128"))
    product_id = payload.get("product_id")
    if isinstance(product_id, bool) or not isinstance(product_id, int):
        raise ValueError("BARCODE_PRODUCT_INVALID")
    product = db.scalar(select(InventoryItem).where(
        InventoryItem.id == product_id,
        InventoryItem.store_id == user.store_id,
        InventoryItem.deleted_at.is_(None),
    ))
    if product is None:
        raise ValueError("BARCODE_PRODUCT_NOT_FOUND")
    created = barcode is None
    if created:
        if operation.operation == "UPDATE":
            raise ValueError("BARCODE_NOT_FOUND")
        barcode = ProductBarcode(id=operation.entity_id, store_id=user.store_id, product_id=product.id, value=value, source="manufacturer")
        db.add(barcode)
    elif operation.base_version is not None and barcode.version != operation.base_version:
        return SyncOperationResult(operation_id=operation.operation_id, status="conflict", entity_id=barcode.id, record=BarcodeOut.model_validate(barcode).model_dump(mode="json"), error="Server record has a newer version")

    source = payload.get("source")
    meaning = payload.get("meaning")
    scan_quantity = payload.get("scan_quantity")
    if source not in {"manufacturer", "tanzim"}:
        raise ValueError("BARCODE_SOURCE_INVALID")
    if meaning not in {"unit", "package"}:
        raise ValueError("BARCODE_MEANING_INVALID")
    if isinstance(scan_quantity, bool) or not isinstance(scan_quantity, int) or scan_quantity < 1:
        raise ValueError("BARCODE_SCAN_QUANTITY_INVALID")
    if meaning == "unit" and scan_quantity != 1:
        raise ValueError("UNIT_BARCODE_QUANTITY_INVALID")
    if source == "tanzim":
        raise ValueError("INTERNAL_BARCODE_SERVER_ISSUED_ONLY")

    if created:
        product_category = db.get(Category, product.category_id) if product.category_id is not None else None
        try:
            reservation = reserve_external_barcode(
                db,
                store_id=user.store_id,
                product_id=product.id,
                value=value,
                category_reference_key=(product_category.reference_key if product_category else None),
            )
        except ValueError as error:
            return SyncOperationResult(operation_id=operation.operation_id, status="conflict", entity_id=operation.entity_id, error=str(error))
        barcode.reservation_id = reservation.id
    elif barcode.value != value:
        raise ValueError("BARCODE_VALUE_IMMUTABLE")

    barcode.product_id = product.id
    barcode.value = value
    barcode.source = source
    barcode.symbology = symbology
    barcode.meaning = meaning
    barcode.scan_quantity = scan_quantity
    requested_active = bool(payload.get("is_active", True))
    if not created and barcode.lifecycle_status != "active" and requested_active:
        raise ValueError("BARCODE_REACTIVATION_FORBIDDEN")
    barcode.is_active = requested_active
    barcode.is_default = bool(payload.get("is_default", False))
    barcode.version = 1 if created else barcode.version + 1
    barcode.lifecycle_status = "active" if barcode.is_active else "retired"
    reservation = db.get(BarcodeReservation, barcode.reservation_id)
    if reservation is not None and not barcode.is_active:
        reservation.status = "retired"
        reservation.retired_at = datetime.now(timezone.utc)
    if barcode.is_default:
        for current in db.scalars(select(ProductBarcode).where(
            ProductBarcode.store_id == user.store_id,
            ProductBarcode.product_id == product.id,
            ProductBarcode.id != barcode.id,
            ProductBarcode.is_default.is_(True),
        )):
            current.is_default = False
            current.version += 1
    db.flush()
    return SyncOperationResult(
        operation_id=operation.operation_id,
        status="applied",
        entity_id=barcode.id,
        record=BarcodeOut.model_validate(barcode).model_dump(mode="json"),
    )


def _apply_inventory_movement(db: DbSession, user: User, operation: SyncOperationIn) -> SyncOperationResult:
    if operation.operation != "CREATE":
        raise ValueError("INVENTORY_MOVEMENT_IMMUTABLE")
    payload = operation.payload or {}
    product_id = payload.get("product_id")
    delta = payload.get("delta")
    kind = payload.get("kind")
    if isinstance(product_id, bool) or not isinstance(product_id, int):
        raise ValueError("MOVEMENT_PRODUCT_INVALID")
    if isinstance(delta, bool) or not isinstance(delta, int) or delta == 0:
        raise ValueError("MOVEMENT_DELTA_INVALID")
    if kind not in {"receive", "issue", "correction", "reversal"}:
        raise ValueError("MOVEMENT_KIND_INVALID")
    if (kind == "receive" and delta < 0) or (kind == "issue" and delta > 0):
        raise ValueError("MOVEMENT_DIRECTION_INVALID")

    item = db.scalar(
        select(InventoryItem)
        .options(joinedload(InventoryItem.catalog_product), selectinload(InventoryItem.labels))
        .where(InventoryItem.id == product_id, InventoryItem.store_id == user.store_id, InventoryItem.deleted_at.is_(None))
        .with_for_update()
    )
    if item is None:
        raise ValueError("PRODUCT_NOT_FOUND")
    if item.is_hidden:
        raise ValueError("PRODUCT_HIDDEN")

    before = item.quantity
    correction_quantity = payload.get("correction_quantity")
    if kind == "correction":
        expected = payload.get("before_quantity")
        if expected != before:
            return SyncOperationResult(operation_id=operation.operation_id, status="conflict", entity_id=operation.entity_id, record={"product": _serialize(item)}, error="CORRECTION_STALE")
        if isinstance(correction_quantity, bool) or not isinstance(correction_quantity, int) or correction_quantity < 0:
            raise ValueError("CORRECTION_QUANTITY_INVALID")
        after = correction_quantity
        if after - before != delta:
            raise ValueError("CORRECTION_DELTA_INVALID")
    else:
        after = before + delta
    if after < 0:
        return SyncOperationResult(operation_id=operation.operation_id, status="conflict", entity_id=operation.entity_id, record={"product": _serialize(item)}, error="INSUFFICIENT_STOCK")
    if after > MAX_PRODUCT_QUANTITY:
        raise ValueError(PRODUCT_QUANTITY_LIMIT_ERROR)

    reverses = payload.get("reverses_operation_id")
    if kind == "reversal":
        if not isinstance(reverses, str):
            raise ValueError("REVERSAL_REFERENCE_REQUIRED")
        original = db.scalar(select(InventoryMovement).where(
            InventoryMovement.store_id == user.store_id,
            InventoryMovement.actor_user_id == user.id,
            InventoryMovement.operation_id == reverses,
        ))
        if original is None or original.product_id != item.id or delta != -original.delta:
            raise ValueError("REVERSAL_REFERENCE_INVALID")
        already_reversed = db.scalar(select(InventoryMovement).where(
            InventoryMovement.store_id == user.store_id,
            InventoryMovement.actor_user_id == user.id,
            InventoryMovement.reverses_operation_id == reverses,
        ))
        if already_reversed is not None:
            return SyncOperationResult(operation_id=operation.operation_id, status="conflict", entity_id=operation.entity_id, record={"product": _serialize(item)}, error="MOVEMENT_ALREADY_REVERSED")

    barcode_id = payload.get("barcode_id")
    scan_quantity = payload.get("scan_quantity", 1)
    if isinstance(scan_quantity, bool) or not isinstance(scan_quantity, int) or scan_quantity < 1:
        raise ValueError("MOVEMENT_SCAN_QUANTITY_INVALID")
    barcode = None
    if barcode_id is not None:
        barcode = db.scalar(select(ProductBarcode).where(
            ProductBarcode.id == barcode_id,
            ProductBarcode.store_id == user.store_id,
            ProductBarcode.product_id == item.id,
            ProductBarcode.is_active.is_(True),
        ))
        if barcode is None:
            raise ValueError("BARCODE_NOT_AVAILABLE")
        if barcode.value != payload.get("barcode_value") or barcode.scan_quantity != scan_quantity:
            raise ValueError("BARCODE_MEANING_MISMATCH")

    context = active_store_context(db, user)
    movement = InventoryMovement(
        id=operation.entity_id,
        store_id=context.store.id,
        product_id=item.id,
        actor_user_id=user.id,
        actor_membership_id=context.membership.id,
        operation_id=operation.operation_id,
        kind=kind,
        delta=delta,
        correction_quantity=correction_quantity if kind == "correction" else None,
        scan_source=payload.get("scan_source") if payload.get("scan_source") in {"manual", "hardware", "camera"} else "manual",
        barcode_id=barcode.id if barcode else None,
        barcode_value=barcode.value if barcode else None,
        scan_quantity=scan_quantity,
        before_quantity=before,
        after_quantity=after,
        reverses_operation_id=reverses,
        client_occurred_at=operation.client_occurred_at,
    )
    db.add(movement)
    item.quantity = after
    item.version = (item.version or 1) + 1
    db.add(InventoryTransaction(
        store_id=context.store.id,
        actor_user_id=user.id,
        user_id=user.data_owner_id,
        inventory_item_id=item.id,
        type="stock_in" if delta > 0 else "stock_out",
        quantity=abs(delta),
        before_quantity=before,
        after_quantity=after,
        note=f"barcode:{kind}",
    ))
    db.flush()
    record = _serialize(item)
    _record_change(db, user, item.id, "UPSERT", record)
    return SyncOperationResult(
        operation_id=operation.operation_id,
        status="applied",
        entity_id=movement.id,
        record={
            "movement": InventoryMovementOut.model_validate(movement).model_dump(mode="json"),
            "product": record,
        },
    )


def _record_quantity_change(
    db: DbSession,
    user: User,
    item: InventoryItem,
    before_quantity: int,
) -> None:
    delta = item.quantity - before_quantity
    if delta == 0:
        return
    db.add(
        InventoryTransaction(
            store_id=user.store_id,
            actor_user_id=user.id,
            user_id=user.data_owner_id,
            inventory_item_id=item.id,
            type="stock_in" if delta > 0 else "stock_out",
            quantity=abs(delta),
            before_quantity=before_quantity,
            after_quantity=item.quantity,
            note="Recorded by offline synchronization",
        )
    )


async def _save_image(file: UploadFile, previous: str | None) -> str:
    extension = _IMAGE_EXTENSIONS.get(file.content_type or "")
    if extension is None:
        raise ValueError("Unsupported image format")

    content = await file.read()
    if len(content) > _MAX_IMAGE_BYTES:
        raise ValueError("Image is larger than 10 MB")

    filename = f"sync-{uuid.uuid4().hex}{extension}"
    (settings.UPLOAD_DIR / filename).write_bytes(content)

    if previous and previous.startswith("/uploads/"):
        (settings.UPLOAD_DIR / Path(previous).name).unlink(missing_ok=True)

    return f"/uploads/{filename}"


def _record_change(
    db: DbSession,
    user: User,
    entity_id: int,
    operation: str,
    payload: dict | None,
) -> SyncChange:
    change = SyncChange(
        store_id=user.store_id,
        actor_user_id=user.id,
        user_id=user.data_owner_id,
        entity="product",
        entity_id=entity_id,
        operation=operation,
        payload=json.dumps(payload) if payload is not None else None,
    )
    db.add(change)
    db.flush()
    return change


async def _apply_product_operation(
    db: DbSession,
    current_user: User,
    operation: SyncOperationIn,
    image_files: dict[str, UploadFile],
    *,
    accepted_at: datetime,
) -> SyncOperationResult:
    item = db.scalar(
        select(InventoryItem)
        .options(joinedload(InventoryItem.catalog_product), selectinload(InventoryItem.labels))
        .where(
            InventoryItem.id == operation.entity_id,
            InventoryItem.store_id == current_user.store_id,
        )
    )

    if operation.operation == "DELETE":
        if item is not None:
            if item.is_catalog_backed:
                raise ValueError("CATALOG_BACKED_PRODUCT_DELETE_FORBIDDEN")
            private_catalog = item.catalog_product if not item.catalog_product.is_shared else None
            if item.image_url and item.image_url.startswith("/uploads/"):
                (settings.UPLOAD_DIR / Path(item.image_url).name).unlink(missing_ok=True)
            for reservation in db.scalars(select(BarcodeReservation).where(
                BarcodeReservation.store_id == current_user.store_id,
                BarcodeReservation.target_type == "product",
                BarcodeReservation.target_id == item.id,
            )):
                reservation.status = "deleted"
                reservation.retired_at = accepted_at
            db.delete(item)
            db.flush()
            if private_catalog is not None:
                db.delete(private_catalog)
                db.flush()
        _record_change(db, current_user, operation.entity_id, "DELETE", None)
        return SyncOperationResult(
            operation_id=operation.operation_id,
            status="applied",
            entity_id=operation.entity_id,
        )

    payload = operation.payload or {}
    if operation.operation == "UPDATE" and item is None:
        raise ValueError("PRODUCT_NOT_FOUND")
    if item is not None and operation.base_version is not None and item.version != operation.base_version:
        return SyncOperationResult(
            operation_id=operation.operation_id,
            status="conflict",
            entity_id=operation.entity_id,
            record=InventoryOut.model_validate(_serialize(item)),
            error="Server record has a newer version",
        )

    created = item is None
    store = db.scalar(
        select(Store)
        .where(Store.id == current_user.store_id)
        .with_for_update()
    )
    if store is None:
        raise ValueError("STORE_NOT_FOUND")
    adoption_catalog: CatalogProduct | None = None
    catalog_payload = payload.get("catalog_product")
    catalog_id = (
        catalog_payload.get("id")
        if isinstance(catalog_payload, dict)
        else None
    )
    if (
        created
        and settings.CATALOG_ON_DEMAND_ADOPTION_ENABLED
        and isinstance(catalog_id, int)
        and not isinstance(catalog_id, bool)
        and catalog_id > 0
    ):
        adoption_catalog = _catalog_for_operation(db, current_user, operation)
        existing_adoption = db.scalar(
            select(InventoryItem)
            .options(
                joinedload(InventoryItem.catalog_product),
                selectinload(InventoryItem.labels),
            )
            .where(
                InventoryItem.store_id == current_user.store_id,
                InventoryItem.catalog_product_id == adoption_catalog.id,
            )
        )
        if existing_adoption is not None:
            record = _serialize(existing_adoption)
            return SyncOperationResult(
                operation_id=operation.operation_id,
                status="conflict",
                entity_id=existing_adoption.id,
                record=InventoryOut.model_validate(record),
                error="CATALOG_ALREADY_ADOPTED",
            )
    requested_category_id = payload.get("category_id")
    if created:
        category = validate_category_for_new_intent(db, store, requested_category_id)
    else:
        category = None
        if (
            store.taxonomy_version == TAXONOMY_VERSION
            and "category_id" in payload
            and requested_category_id != item.category_id
        ):
            raise ValueError("CATEGORY_CHANGE_REQUIRES_PREVIEW")
    if item is None:
        limit = None if is_admin(current_user) else locked_inventory_capacity(
            db, current_user, as_of=accepted_at
        )
        count = db.scalar(
            select(func.count(InventoryItem.id)).where(
                InventoryItem.store_id == current_user.store_id
            )
        ) or 0
        if limit is not None and count >= limit:
            raise ValueError("INVENTORY_LIMIT_REACHED")
        catalog = adoption_catalog or _catalog_for_operation(db, current_user, operation)
        item = InventoryItem(
            store_id=current_user.store_id,
            id=operation.entity_id,
            user_id=current_user.data_owner_id,
            catalog_product_id=catalog.id,
            catalog_product=catalog,
            is_catalog_backed=catalog.is_shared,
        )
        db.add(item)
    before_quantity = item.quantity or 0
    _apply_fields(db, current_user.store_id, item, payload)
    _record_quantity_change(db, current_user, item, before_quantity)
    if (
        operation.operation == "UPDATE"
        and "image_url" in payload
        and payload.get("image_url") is None
    ):
        if item.image_url and item.image_url.startswith("/uploads/"):
            (settings.UPLOAD_DIR / Path(item.image_url).name).unlink(missing_ok=True)
        item.image_url = None
        item.media_asset_id = None
    if "media_asset_id" in payload:
        media_asset_id = payload.get("media_asset_id")
        if media_asset_id is None:
            item.image_url = None
            item.media_asset_id = None
        elif not isinstance(media_asset_id, str):
            raise ValueError("MEDIA_ASSET_INVALID")
        else:
            asset = db.scalar(select(MediaAsset).where(
                MediaAsset.id == media_asset_id,
                MediaAsset.store_id == current_user.store_id,
            ))
            if asset is None:
                raise ValueError("MEDIA_ASSET_NOT_AVAILABLE")
            item.media_asset_id = asset.id
            item.image_url = f"/api/media/{asset.id}/detail"
    image = image_files.get(operation.operation_id)
    if image is not None:
        item.image_url = await _save_image(image, item.image_url)
        item.media_asset_id = None
    item.version = 1 if created else (item.version or 1) + 1
    db.flush()
    if created:
        external_barcodes = payload.get("external_barcodes")
        internal_barcode = payload.get("internal_barcode")
        if external_barcodes is not None and internal_barcode is not None:
            raise ValueError("PRODUCT_BARCODE_INTENT_AMBIGUOUS")
        if external_barcodes is not None:
            _create_embedded_external_barcodes(
                db, store=store, product=item, category=category, payload=external_barcodes,
            )
        elif store.taxonomy_version == TAXONOMY_VERSION:
            assert category is not None
            if internal_barcode is not None:
                if (
                    not isinstance(internal_barcode, dict)
                    or internal_barcode.get("source") != "tanzim"
                    or internal_barcode.get("symbology") != "datamatrix"
                    or isinstance(internal_barcode.get("id"), bool)
                    or not isinstance(internal_barcode.get("id"), int)
                    or internal_barcode["id"] <= 0
                ):
                    raise ValueError("INTERNAL_BARCODE_COMMAND_INVALID")
                try:
                    issue_internal_barcode(
                        db,
                        store,
                        item,
                        category,
                        requested_value=internal_barcode.get("value"),
                        requested_barcode_id=internal_barcode["id"],
                    )
                except HTTPException as error:
                    raise ValueError(str(error.detail)) from error
            elif operation.execution_mode == "solo":
                raise ValueError("INTERNAL_BARCODE_COMMAND_REQUIRED")
            else:
                issue_internal_barcode(db, store, item, category)
        elif internal_barcode is not None:
            raise ValueError("TAXONOMY_ADOPTION_REQUIRED")
    store.has_historical_inventory_usage = True
    db.refresh(item)
    record = _serialize(item)
    _record_change(db, current_user, item.id, "UPSERT", record)
    return SyncOperationResult(
        operation_id=operation.operation_id,
        status="applied",
        entity_id=item.id,
        record=InventoryOut.model_validate(record),
    )


@router.post("/batch", response_model=SyncBatchResponse)
async def push_batch(
    http_request: Request,
    operations_json: Annotated[str, Form()],
    current_user: CurrentProductReader,
    db: DbSession,
    files: Annotated[list[UploadFile] | None, File()] = None,
    client_data_schema: Annotated[int | None, Header(alias="X-Client-Data-Schema")] = None,
) -> SyncBatchResponse:
    _require_store_aware_client(client_data_schema)
    permissions = effective_permissions(active_store_context(db, current_user))
    projection_schema = client_data_schema or 2
    batch_request = SyncBatchRequest.model_validate_json(operations_json)
    image_files = {file.filename: file for file in files or [] if file.filename}
    results: list[SyncOperationResult] = []

    for operation in batch_request.operations:
        fingerprint = await _operation_fingerprint(
            operation,
            image_files.get(operation.operation_id),
        )
        _serialize_operation_submission(
            db,
            current_user.store_id,
            current_user.id,
            operation.operation_id,
        )
        previous = db.scalar(
            select(SyncOperation).where(
                SyncOperation.store_id == current_user.store_id,
                SyncOperation.actor_user_id == current_user.id,
                SyncOperation.operation_id == operation.operation_id,
            )
        )
        if previous is not None:
            results.append(_duplicate_result(previous, operation, fingerprint))
            db.commit()
            continue

        accepted_at = datetime.now(timezone.utc)
        try:
            validate_sync_acceptance(db, current_user, operation)
            _authorize_operation(db, current_user, operation, accepted_at=accepted_at)
        except ValueError as error:
            result = SyncOperationResult(operation_id=operation.operation_id, status="fatal_error", entity_id=operation.entity_id, error=str(error))
            record_store_activity(db, current_user, action=f"sync.{operation.operation.lower()}", target_entity=operation.entity, target_id=operation.entity_id, operation_id=operation.operation_id, after=_activity_evidence(operation), outcome="rejected", client_occurred_at=operation.client_occurred_at)
            db.add(SyncOperation(store_id=current_user.store_id, actor_user_id=current_user.id, user_id=current_user.data_owner_id, operation_id=operation.operation_id, request_fingerprint=fingerprint, result_payload=result.model_dump_json(), execution_mode=operation.execution_mode, policy_version=operation.policy_version))
            db.commit(); results.append(result); continue

        if operation.entity == "invoice":
            try:
                with db.begin_nested():
                    if operation.operation == "CREATE":
                        record = post_invoice(
                            db, current_user,
                            invoice_id=operation.entity_id,
                            operation_id=operation.operation_id,
                            payload=operation.payload or {},
                            client_occurred_at=operation.client_occurred_at,
                        )
                        action = "invoice.posted"
                    else:
                        record = cancel_invoice(
                            db, current_user,
                            invoice_id=operation.entity_id,
                            operation_id=operation.operation_id,
                            client_occurred_at=operation.client_occurred_at,
                        )
                        action = "invoice.cancelled"
                    result = SyncOperationResult(
                        operation_id=operation.operation_id,
                        status="applied",
                        entity_id=operation.entity_id,
                        record=record,
                    )
            except ValueError as error:
                code = str(error)
                status = "conflict" if code in {
                    "INSUFFICIENT_STOCK", "INSUFFICIENT_REVERSAL_STOCK",
                    "INVOICE_ID_EXISTS", "INVOICE_ALREADY_CANCELLED",
                } else "fatal_error"
                result = SyncOperationResult(
                    operation_id=operation.operation_id,
                    status=status,
                    entity_id=operation.entity_id,
                    error=code,
                )
                action = "invoice.posted" if operation.operation == "CREATE" else "invoice.cancelled"
            record_store_activity(
                db, current_user, action=action, target_entity="invoice",
                target_id=operation.entity_id, operation_id=operation.operation_id,
                after=_activity_evidence(operation, result),
                outcome="applied" if result.status == "applied" else ("conflict" if result.status == "conflict" else "rejected"),
                client_occurred_at=operation.client_occurred_at,
            )
            db.add(SyncOperation(
                store_id=current_user.store_id, actor_user_id=current_user.id,
                user_id=current_user.data_owner_id, operation_id=operation.operation_id,
                request_fingerprint=fingerprint, result_payload=result.model_dump_json(),
                execution_mode=operation.execution_mode, policy_version=operation.policy_version,
            ))
            db.commit()
            results.append(result)
            continue

        if operation.entity in {"barcode", "inventory_movement"}:
            try:
                with db.begin_nested():
                    if operation.entity == "barcode":
                        result = _apply_barcode(db, current_user, operation)
                    else:
                        result = _apply_inventory_movement(db, current_user, operation)
            except ValueError as error:
                result = SyncOperationResult(operation_id=operation.operation_id, status="fatal_error", entity_id=operation.entity_id, error=str(error))
            action = (
                f"barcode.{operation.operation.lower()}"
                if operation.entity == "barcode"
                else f"inventory.scan.{(operation.payload or {}).get('kind', 'change')}"
            )
            record_store_activity(
                db,
                current_user,
                action=action,
                target_entity=operation.entity,
                target_id=operation.entity_id,
                operation_id=operation.operation_id,
                after=_activity_evidence(operation, result),
                outcome="applied" if result.status == "applied" else ("conflict" if result.status == "conflict" else "rejected"),
                client_occurred_at=operation.client_occurred_at,
            )
            db.add(SyncOperation(store_id=current_user.store_id, actor_user_id=current_user.id, user_id=current_user.data_owner_id, operation_id=operation.operation_id, request_fingerprint=fingerprint, result_payload=result.model_dump_json(), execution_mode=operation.execution_mode, policy_version=operation.policy_version))
            db.commit()
            results.append(result)
            continue

        if operation.entity in {"label", "category"}:
            try:
                with db.begin_nested():
                    tool_id = "labels" if operation.entity == "label" else "categories"
                    capability = "labels.write" if operation.entity == "label" else "categories.write"
                    if not is_admin(current_user):
                        entitlement = entitlement_for_user(db, current_user, as_of=accepted_at)
                        if not entitlement["capabilities"].get(capability, False):
                            if entitlement["status"] == "expired":
                                raise ValueError("ENTITLEMENT_EXPIRED")
                            raise ValueError(f"CAPABILITY_REQUIRED:{capability}")
                    if not tool_allowed(db, current_user, tool_id):
                        raise ValueError(f"DOMAIN_TOOL_DISABLED:{tool_id}")
                    result = (_apply_label if operation.entity == "label" else _apply_category)(
                        db, current_user, operation
                    )
                    entity_model = Label if operation.entity == "label" else Category
                    entity_record = db.get(entity_model, operation.entity_id)
                    if entity_record is not None:
                        entity_record.store_id = current_user.store_id
            except ValueError as error:
                result = SyncOperationResult(operation_id=operation.operation_id, status="fatal_error", entity_id=operation.entity_id, error=str(error))
            record_store_activity(db, current_user, action=f"sync.{operation.operation.lower()}", target_entity=operation.entity, target_id=operation.entity_id, operation_id=operation.operation_id, after=_activity_evidence(operation, result), outcome="applied" if result.status == "applied" else "rejected", client_occurred_at=operation.client_occurred_at)
            db.add(SyncOperation(store_id=current_user.store_id, actor_user_id=current_user.id, user_id=current_user.data_owner_id, operation_id=operation.operation_id, request_fingerprint=fingerprint, result_payload=result.model_dump_json(), execution_mode=operation.execution_mode, policy_version=operation.policy_version))
            db.commit()
            results.append(result)
            continue

        try:
            with db.begin_nested():
                result = await _apply_product_operation(
                    db,
                    current_user,
                    operation,
                    image_files,
                    accepted_at=accepted_at,
                )
        except ValueError as error:
            result = SyncOperationResult(
                operation_id=operation.operation_id,
                status="fatal_error",
                entity_id=operation.entity_id,
                error=str(error),
            )

        db.add(
            SyncOperation(
                store_id=current_user.store_id,
                actor_user_id=current_user.id,
                user_id=current_user.data_owner_id,
                operation_id=operation.operation_id,
                request_fingerprint=fingerprint,
                result_payload=result.model_dump_json(),
                execution_mode=operation.execution_mode,
                policy_version=operation.policy_version,
            )
        )
        record_store_activity(db, current_user, action=f"sync.{operation.operation.lower()}", target_entity=operation.entity, target_id=operation.entity_id, operation_id=operation.operation_id, after=_activity_evidence(operation, result), outcome="applied" if result.status == "applied" else ("conflict" if result.status == "conflict" else "rejected"), client_occurred_at=operation.client_occurred_at)
        db.commit()
        results.append(result)

    cursor = db.scalar(
        select(func.max(SyncChange.id)).where(SyncChange.store_id == current_user.store_id)
    ) or 0
    operations_by_id = {item.operation_id: item for item in batch_request.operations}
    request_id = getattr(http_request.state, "request_id", "unavailable")
    for result in results:
        if result.status == "applied":
            continue
        operation = operations_by_id.get(result.operation_id)
        error_code = result.error if result.error and _SAFE_DIAGNOSTIC_CODE.fullmatch(result.error) else "UNCLASSIFIED"
        logger.warning(
            "Sync operation not applied request_id=%s store_id=%s actor_user_id=%s operation_id=%s entity=%s action=%s status=%s code=%s",
            request_id,
            current_user.store_id,
            current_user.id,
            result.operation_id,
            operation.entity if operation else "unknown",
            operation.operation if operation else "unknown",
            result.status,
            error_code,
        )
    for result in results:
        if isinstance(result.record, InventoryOut):
            raw_record = result.record.model_dump(mode="json")
        elif isinstance(result.record, dict):
            raw_record = result.record
        else:
            continue
        if "catalog_product_id" in raw_record:
            result.record = _project_record(raw_record, permissions, projection_schema)
        elif isinstance(raw_record.get("product"), dict):
            result.record = {**raw_record, "product": _project_record(raw_record["product"], permissions, projection_schema)}
    return SyncBatchResponse(results=results, cursor=cursor)


@router.get("/barcodes", response_model=BarcodeSnapshot)
def barcode_snapshot(
    current_user: CurrentProductReader,
    db: DbSession,
    client_data_schema: Annotated[int | None, Header(alias="X-Client-Data-Schema")] = None,
) -> BarcodeSnapshot:
    _require_store_aware_client(client_data_schema)
    permissions = effective_permissions(active_store_context(db, current_user))
    if StorePermission.BARCODE_LOOKUP.value not in permissions:
        raise HTTPException(status_code=403, detail=f"PERMISSION_REQUIRED:{StorePermission.BARCODE_LOOKUP.value}")
    entitlement = entitlement_for_user(db, current_user)
    if not entitlement["capabilities"].get("sync", False):
        detail = "ENTITLEMENT_EXPIRED" if entitlement["status"] == "expired" else "CAPABILITY_REQUIRED:sync"
        raise HTTPException(status_code=403, detail=detail)
    if not entitlement["capabilities"].get("barcode.lookup", False):
        detail = "ENTITLEMENT_EXPIRED" if entitlement["status"] == "expired" else "CAPABILITY_REQUIRED:barcode.lookup"
        raise HTTPException(status_code=403, detail=detail)
    items = list(db.scalars(select(ProductBarcode).where(ProductBarcode.store_id == current_user.store_id)))
    return BarcodeSnapshot(items=[BarcodeOut.model_validate(item) for item in items])


@router.get("/changes", response_model=SyncChangesResponse)
def pull_changes(
    current_user: CurrentProductReader,
    db: DbSession,
    cursor: int = 0,
    client_data_schema: Annotated[int | None, Header(alias="X-Client-Data-Schema")] = None,
) -> SyncChangesResponse:
    _require_store_aware_client(client_data_schema)
    entitlement = entitlement_for_user(db, current_user)
    if not entitlement["capabilities"].get("sync", False):
        detail = "ENTITLEMENT_EXPIRED" if entitlement["status"] == "expired" else "CAPABILITY_REQUIRED:sync"
        raise HTTPException(status_code=403, detail=detail)
    permissions = effective_permissions(active_store_context(db, current_user))
    projection_schema = client_data_schema or 2
    latest = db.scalar(
        select(func.max(SyncChange.id)).where(SyncChange.store_id == current_user.store_id)
    ) or 0

    if cursor == 0:
        items = list(
            db.scalars(
                select(InventoryItem)
                .options(joinedload(InventoryItem.catalog_product), selectinload(InventoryItem.labels))
                .where(InventoryItem.store_id == current_user.store_id)
            )
        )
        return SyncChangesResponse(
            cursor=latest,
            changes=[
                SyncChangeOut(
                    cursor=latest,
                    entity="product",
                    entity_id=item.id,
                    operation="UPSERT",
                    record=_project_record(_serialize(item), permissions, projection_schema),
                )
                for item in items
            ],
        )

    changes = list(
        db.scalars(
            select(SyncChange)
            .where(SyncChange.store_id == current_user.store_id, SyncChange.id > cursor)
            .order_by(SyncChange.id)
            .limit(500)
        )
    )
    return SyncChangesResponse(
        cursor=changes[-1].id if changes else latest,
        changes=[
            SyncChangeOut(
                cursor=change.id,
                entity="product",
                entity_id=change.entity_id,
                operation=change.operation,
                record=_project_record(json.loads(change.payload), permissions, projection_schema) if change.payload else None,
            )
            for change in changes
        ],
    )
