from fastapi import APIRouter, HTTPException, Query, status

from ..deps import CurrentCatalogManager, CurrentCatalogUser, DbSession

from ..schemas import (
    CatalogAdoptionStatus,
    CatalogProductCreate,
    CatalogProductUpdate,
    CatalogProductOut,
    CatalogProductPage,
)
from ..config import settings

from ..services import catalog_product_service

router = APIRouter(
    prefix="/catalog-products",
    tags=["catalog-products"],
)


@router.get("/adoption-status", response_model=CatalogAdoptionStatus)
def catalog_adoption_status(_: CurrentCatalogUser):
    return CatalogAdoptionStatus(
        enabled=settings.CATALOG_ON_DEMAND_ADOPTION_ENABLED,
        cursor_read_v2_enabled=settings.CATALOG_CURSOR_READ_V2_ENABLED,
        reference_media_v1_enabled=settings.CATALOG_REFERENCE_MEDIA_V1_ENABLED,
        offline_families_v1_enabled=settings.CATALOG_OFFLINE_FAMILIES_V1_ENABLED,
    )


@router.get("/page", response_model=CatalogProductPage)
def list_catalog_products_page(
    _: CurrentCatalogUser,
    db: DbSession,
    search: str | None = Query(default=None, max_length=200),
    industry_id: int | None = Query(default=None, gt=0),
    cursor: str | None = Query(default=None, max_length=1000),
    limit: int = Query(default=24, ge=1, le=100),
):
    if not settings.CATALOG_CURSOR_READ_V2_ENABLED:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="CATALOG_CURSOR_READ_V2_DISABLED")
    try:
        items, next_cursor, has_more = catalog_product_service.list_catalog_products_page(
            db, search=search, industry_id=industry_id, cursor=cursor, limit=limit
        )
    except ValueError as error:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(error)) from error
    return CatalogProductPage(items=items, next_cursor=next_cursor, has_more=has_more)


# =========================================================
# LIST
# =========================================================
@router.get(
    "",
    response_model=list[CatalogProductOut],
)
def list_catalog_products(
    current_user: CurrentCatalogUser,
    db: DbSession,
    search: str | None = Query(default=None, max_length=200),
    industry_id: int | None = Query(default=None, gt=0),
):
    return catalog_product_service.list_catalog_products(
        db=db,
        search=search,
        industry_id=industry_id,
    )


# =========================================================
# ARCHIVED LIST (ADMIN)
# =========================================================
@router.get(
    "/archived",
    response_model=list[CatalogProductOut],
)
def list_archived_catalog_products(
    _: CurrentCatalogManager,
    db: DbSession,
    search: str | None = Query(default=None, max_length=200),
    industry_id: int | None = Query(default=None, gt=0),
):
    return catalog_product_service.list_archived_catalog_products(
        db=db,
        search=search,
        industry_id=industry_id,
    )


# =========================================================
# GET ONE
# =========================================================
@router.get(
    "/{catalog_id}",
    response_model=CatalogProductOut,
)
def get_catalog(
    catalog_id: int,
    _: CurrentCatalogUser,
    db: DbSession,
):
    return catalog_product_service.get_catalog_product_or_404(db, catalog_id)


# =========================================================
# CREATE
# =========================================================
@router.post(
    "",
    response_model=CatalogProductOut,
    status_code=status.HTTP_201_CREATED,
)
def create_catalog(
    payload: CatalogProductCreate,
    _: CurrentCatalogManager,
    db: DbSession,
):
    return catalog_product_service.create_catalog_product(
        db,
        payload,
    )


# =========================================================
# UPDATE
# =========================================================
@router.patch(
    "/{catalog_id}",
    response_model=CatalogProductOut,
)
def update_catalog(
    catalog_id: int,
    payload: CatalogProductUpdate,
    _: CurrentCatalogManager,
    db: DbSession,
):
    return catalog_product_service.update_catalog_product(
        db,
        catalog_id,
        payload,
    )


# =========================================================
# ARCHIVE / RESTORE
# =========================================================
@router.patch(
    "/{catalog_id}/archive",
    response_model=CatalogProductOut,
)
def archive_catalog(
    catalog_id: int,
    admin: CurrentCatalogManager,
    db: DbSession,
):
    return catalog_product_service.archive_catalog_product(db, catalog_id, admin)


@router.patch(
    "/{catalog_id}/restore",
    response_model=CatalogProductOut,
)
def restore_catalog(
    catalog_id: int,
    admin: CurrentCatalogManager,
    db: DbSession,
):
    return catalog_product_service.restore_catalog_product(db, catalog_id, admin)


# =========================================================
# PERMANENT DELETE
# =========================================================
@router.delete(
    "/{catalog_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
def delete_catalog(
    catalog_id: int,
    admin: CurrentCatalogManager,
    db: DbSession,
):
    catalog_product_service.permanently_delete_catalog_product(
        db,
        catalog_id,
        admin,
    )

    return
