from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, status, Query
from sqlalchemy import select, func
from sqlalchemy.orm import joinedload
from ..services.inventory_service import (
    get_inventory_item_or_404,
    update_inventory_item as apply_inventory_update,
)

from ..deps import CurrentProductReader, CurrentWritableUser, DbSession
from ..models import InventoryItem, InventoryTransaction
from ..services.store_authorization import StorePermission, require_store_permission, project_inventory_item
from ..inventory_policy import MAX_PRODUCT_QUANTITY, PRODUCT_QUANTITY_LIMIT_ERROR
from ..schemas import (
    InventoryBulkSync,
    InventoryOut,
    InventoryListResponse,
    InventoryMeta,
    InventoryUpdate,
    MessageResponse,
    TransactionCreate,
    TransactionOut,
)

router = APIRouter(prefix="/inventory", tags=["inventory"])


@router.get("/trash", response_model=list[InventoryOut])
def trash_inventory(
    current_user: CurrentProductReader,
    db: DbSession,
) -> list[dict]:
    stmt = (
        select(InventoryItem)
        .where(
            InventoryItem.store_id == current_user.store_id,
            InventoryItem.deleted_at.is_not(None),
        )
        .order_by(InventoryItem.created_at.desc(), InventoryItem.id.desc())
    )

    return [project_inventory_item(db, current_user, item) for item in db.scalars(stmt)]




@router.get("", response_model=InventoryListResponse)
def list_inventory(
    current_user: CurrentProductReader,
    db: DbSession,
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=200),
):
    base_query = (
        select(InventoryItem)
        .where(
            InventoryItem.store_id == current_user.store_id,
            InventoryItem.deleted_at.is_(None),
            InventoryItem.is_hidden.is_(False),
        )
    )

    total = db.scalar(
        select(func.count())
        .select_from(base_query.subquery())
    )

    items = list(
        db.scalars(
            base_query
            .options(
                joinedload(InventoryItem.catalog_product)
            )
            .order_by(InventoryItem.created_at.desc(), InventoryItem.id.desc())
            .offset((page - 1) * limit)
            .limit(limit)
        )
    )

    return InventoryListResponse(
        items=[project_inventory_item(db, current_user, item) for item in items],
        meta=InventoryMeta(
            page=page,
            limit=limit,
            total=total or 0,
        ),
    )

@router.get("/{item_id}", response_model=InventoryOut)
def get_inventory_item(
    item_id: int,
    current_user: CurrentProductReader,
    db: DbSession,
) -> dict:
    return project_inventory_item(db, current_user, get_inventory_item_or_404(
        db,
        item_id,
        current_user.store_id,
    ))


@router.patch("/{item_id}", response_model=InventoryOut)
def update_inventory_item(
    item_id: int,
    payload: InventoryUpdate,
    current_user: CurrentWritableUser,
    db: DbSession,
) -> InventoryItem:
    fields = payload.model_fields_set
    if fields & {"price", "sale_price"}:
        require_store_permission(db, current_user, StorePermission.SALE_PRICE_CHANGE)
    if "purchase_price" in fields:
        require_store_permission(db, current_user, StorePermission.PURCHASE_PRICE_CHANGE)
    if "quantity" in fields:
        require_store_permission(db, current_user, StorePermission.QUANTITY_CHANGE)
    if fields - {"price", "sale_price", "purchase_price", "quantity"}:
        require_store_permission(db, current_user, StorePermission.PRODUCTS_EDIT)
    item = get_inventory_item_or_404(
        db,
        item_id,
        current_user.store_id,
    )

    apply_inventory_update(
        item,
        payload.model_dump(exclude_unset=True),
    )

    db.commit()
    db.refresh(item)

    return project_inventory_item(db, current_user, item)


@router.delete("/{item_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_inventory_item(
    item_id: int,
    current_user: CurrentWritableUser,
    db: DbSession,
):
    item = get_inventory_item_or_404(
        db,
        item_id,
        current_user.store_id,
    )

    if item.is_catalog_backed:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="CATALOG_BACKED_PRODUCT_DELETE_FORBIDDEN",
        )

    item.deleted_at = datetime.now(timezone.utc)

    db.commit()


@router.post("/{item_id}/transaction", response_model=TransactionOut)
def create_transaction(
    item_id: int,
    payload: TransactionCreate,
    current_user: CurrentWritableUser,
    db: DbSession,
) -> InventoryTransaction:
    item = get_inventory_item_or_404(
        db,
        item_id,
        current_user.store_id,
    )

    before_quantity = item.quantity

    if payload.type == "stock_in":
        if item.quantity + payload.quantity > MAX_PRODUCT_QUANTITY:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=PRODUCT_QUANTITY_LIMIT_ERROR,
            )
        item.quantity += payload.quantity

    elif payload.type == "stock_out":
        if item.quantity < payload.quantity:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="موجودی کافی نیست",
            )

        item.quantity -= payload.quantity

    after_quantity = item.quantity

    transaction = InventoryTransaction(
        store_id=current_user.store_id,
        actor_user_id=current_user.id,
        user_id=current_user.data_owner_id,
        inventory_item_id=item.id,
        type=payload.type,
        quantity=payload.quantity,
        before_quantity=before_quantity,
        after_quantity=after_quantity,
        note=payload.note,
    )

    db.add(transaction)
    db.commit()
    db.refresh(transaction)

    return transaction


@router.get("/{item_id}/transactions", response_model=list[TransactionOut])
def list_transactions(
    item_id: int,
    current_user: CurrentProductReader,
    db: DbSession,
) -> list[InventoryTransaction]:
    get_inventory_item_or_404(
        db,
        item_id,
        current_user.store_id,
    )

    stmt = (
        select(InventoryTransaction)
        .where(
            InventoryTransaction.inventory_item_id == item_id
        )
        .order_by(
            InventoryTransaction.created_at.desc(),
            InventoryTransaction.id.desc(),
        )
    )

    return list(db.scalars(stmt))


@router.patch("/{item_id}/hide", response_model=InventoryOut)
def hide_inventory_item(
    item_id: int,
    current_user: CurrentWritableUser,
    db: DbSession,
) -> dict:
    item = get_inventory_item_or_404(
        db,
        item_id,
        current_user.store_id,
    )

    item.is_hidden = True

    db.commit()
    db.refresh(item)

    return project_inventory_item(db, current_user, item)


@router.patch("/{item_id}/restore", response_model=InventoryOut)
def restore_inventory_item(
    item_id: int,
    current_user: CurrentWritableUser,
    db: DbSession,
) -> dict:
    item = get_inventory_item_or_404(
        db,
        item_id,
        current_user.store_id,
    )

    item.is_hidden = False
    item.deleted_at = None

    db.commit()
    db.refresh(item)

    return project_inventory_item(db, current_user, item)


@router.delete("/{item_id}/force", response_model=MessageResponse)
def force_delete_inventory_item(
    item_id: int,
    current_user: CurrentWritableUser,
    db: DbSession,
):
    item = get_inventory_item_or_404(
        db,
        item_id,
        current_user.store_id,
    )

    if item.is_catalog_backed:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="CATALOG_BACKED_PRODUCT_DELETE_FORBIDDEN",
        )

    db.delete(item)
    db.commit()

    return MessageResponse(
        message="آیتم برای همیشه حذف شد"
    )


@router.post("/sync", response_model=MessageResponse)
def bulk_sync_inventory(
    payload: InventoryBulkSync,
    current_user: CurrentWritableUser,
    db: DbSession,
):
    for sync_item in payload.items:
        item = db.get(InventoryItem, sync_item.id)

        if item is None:
            continue

        if item.store_id != current_user.store_id:
            continue

        if item.deleted_at is not None:
            continue

        item.quantity = sync_item.quantity
        item.price = sync_item.price
        item.sale_price = sync_item.price
        item.custom_label = sync_item.custom_label
        item.note = sync_item.note

    db.commit()

    return MessageResponse(
        message="همگام‌سازی با موفقیت انجام شد"
    )
