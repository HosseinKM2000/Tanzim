from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..models import User
from ..mobile import DUPLICATE_MOBILE_MESSAGE, normalize_iranian_mobile
from ..schemas import LoginRequest, TokenResponse, UserOut, SignupRequest, UserUpdate
from .plan_policy import can_add_device
from .store_service import attach_store_context, create_owner_store, owner_store_context

from ..security import (
    create_access_token,
    hash_password,
    verify_password,
)

from .session_service import (
    get_active_sessions,
    get_session_by_fingerprint,
    create_session,
    update_last_seen,
)


def username_taken(
    db: Session,
    username: str,
    exclude_id: int | None = None,
):
    stmt = select(User).where(User.username == username)

    if exclude_id:
        stmt = stmt.where(User.id != exclude_id)

    return db.scalar(stmt) is not None


def _integrity_conflict_detail(error: IntegrityError) -> str:
    constraint_name = getattr(getattr(error, "orig", None), "diag", None)
    constraint_name = getattr(constraint_name, "constraint_name", None)
    message = str(getattr(error, "orig", error)).lower()
    if constraint_name == "uq_users_phone_canonical" or "users.phone" in message:
        return DUPLICATE_MOBILE_MESSAGE
    return "Username already exists"


def signup(
    db: Session,
    payload: SignupRequest,
):

    if username_taken(db, payload.username):
        raise HTTPException(
            status_code=409,
            detail="Username already exists",
        )

    user = User(
        first_name=payload.first_name,
        last_name=payload.last_name,
        username=payload.username,
        email=payload.email,
        phone=payload.phone,
        hashed_password=hash_password(payload.password),
        plan="free",
        is_active=True,
        is_admin=False,
        role="USER",
    )

    db.add(user)
    try:
        db.flush()
    except IntegrityError as error:
        db.rollback()
        raise HTTPException(status_code=409, detail=_integrity_conflict_detail(error)) from error
    create_owner_store(db, user)

    token = create_access_token(user.id)

    create_session(
        db,
        user,
        payload.device_fingerprint,
        token,
    )

    try:
        db.commit()
    except IntegrityError as error:
        db.rollback()
        raise HTTPException(status_code=409, detail=_integrity_conflict_detail(error)) from error
    db.refresh(user)

    attach_store_context(db, user)
    return TokenResponse(
    access_token=token,
    token_type="bearer",
    user=UserOut.model_validate(user),
)


def login(
    db: Session,
    payload: LoginRequest,
) -> TokenResponse:

    # ----------------------------------------------------
    # Authenticate User
    # ----------------------------------------------------
    identifier = payload.username
    try:
        canonical_mobile = normalize_iranian_mobile(identifier)
    except ValueError:
        canonical_mobile = None

    user = None
    if canonical_mobile:
        user = db.scalar(select(User).where(User.phone == canonical_mobile))

    # Keep exact username lookup as a fallback for existing accounts whose
    # username resembles a phone number.
    if user is None:
        user = db.scalar(select(User).where(User.username == identifier))

    if (
        user is None
        or
        not verify_password(
            payload.password,
            user.hashed_password,
        )
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
        )

    if not user.is_active:
        raise HTTPException(status_code=423, detail="ACCOUNT_DISABLED")

    # ----------------------------------------------------
    # Device Session
    # ----------------------------------------------------
    session = get_session_by_fingerprint(
        db=db,
        user_id=user.id,
        fingerprint=payload.device_fingerprint,
    )

    # ----------------------------------------------------
    # Create JWT
    # ----------------------------------------------------
    token = create_access_token(user.id)

    if session:

        update_last_seen(session)

        session.access_token = token

    else:

        # Serialize new-device admission for this account. PostgreSQL row locks
        # prevent concurrent logins from both observing the same free slot.
        db.execute(select(User).where(User.id == user.id).with_for_update())
        active_sessions = get_active_sessions(
            db,
            user.id,
        )

        if not can_add_device(
            db,
            user,
            len(active_sessions),
        ):
            raise HTTPException(
                status_code=403,
                detail="Device limit reached for your plan.",
            )

        create_session(
            db=db,
            user=user,
            fingerprint=payload.device_fingerprint,
            token=token,
        )

    db.commit()
    db.refresh(user)
    attach_store_context(db, user)

    return TokenResponse(
        access_token=token,
        token_type="bearer",
        user=UserOut.model_validate(user),
    )

def update_user(
    db: Session,
    user: User,
    payload: UserUpdate,
):

    data = payload.model_dump(
        exclude_unset=True,
    )
    store_name_supplied = "store_name" in data
    store_name = data.pop("store_name", None)

    if store_name_supplied:
        if not store_name:
            raise HTTPException(status_code=422, detail="STORE_NAME_REQUIRED")
        owner_store_context(db, user).store.name = store_name

    username = data.get("username")

    if username:

        if username_taken(
            db,
            username,
            user.id,
        ):
            raise HTTPException(
                
                status_code=409,
                detail="Username already exists",
            )

    for k, v in data.items():
        setattr(user, k, v)

    try:
        db.commit()
    except IntegrityError as error:
        db.rollback()
        raise HTTPException(status_code=409, detail=_integrity_conflict_detail(error)) from error
    db.refresh(user)
    attach_store_context(db, user)

    return user


def update_password(
    db: Session,
    user: User,
    current_password: str,
    new_password: str,
    current_fingerprint: str,
):
    if not verify_password(current_password, user.hashed_password):
        raise HTTPException(status_code=400, detail="CURRENT_PASSWORD_INCORRECT")
    if verify_password(new_password, user.hashed_password):
        raise HTTPException(status_code=400, detail="NEW_PASSWORD_MUST_DIFFER")

    user.hashed_password = hash_password(new_password)

    context = attach_store_context(db, user)
    if context and context.membership.temporary_password_required:
        context.membership.temporary_password_required = False

    # A credential change invalidates every other device while preserving the
    # verified session that performed the change.
    for session in get_active_sessions(db, user.id):
        if session.device_fingerprint != current_fingerprint:
            session.is_active = False

    db.commit()
    db.refresh(user)

from ..services.session_service import (
    get_session_by_fingerprint,
    deactivate_session,
)


def logout(
    db: Session,
    current_user: User,
    fingerprint: str,
):
    session = get_session_by_fingerprint(
        db=db,
        user_id=current_user.id,
        fingerprint=fingerprint,
    )

    if session:
        deactivate_session(session)

    db.commit()
