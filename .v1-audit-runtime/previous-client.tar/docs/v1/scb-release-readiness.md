# آمادگی انتشار TZ-V1-SCB

وضعیت این سند: **زیرساخت پیاده‌سازی و با rollout gate ایزوله شده است؛ فعال‌سازی مشتری و merge به `draft` مجاز نیست.**

معنای وضعیت‌ها: `PASS` یعنی شاهد خودکار موجود و اجراشده؛ `BLOCKED` یعنی مسیر عمداً غیرفعال است یا شاهد الزامی/تصمیم قرارداد کم است؛ `NOT RUN` فقط برای بررسی محیطی/فیزیکی؛ `N/A` فقط برای variant مستقلِ ناموجود.

## ماتریس پذیرش

| ID | وضعیت | شاهد یا دلیل دقیق |
|---|---|---|
| REF-01 | PASS | validator بسته؛ `test_migration_reaches_head_with_all_expected_tables` شمار 24/281/25/256 را روی PostgreSQL واقعی کنترل می‌کند. |
| REF-02 | PASS | seed داخل migration و uniqueهای reference؛ اجرای upgrade واقعی و بازاجرای Alembic no-op؛ هیچ inventory در seed ساخته نمی‌شود. |
| REF-03 | PASS | `test_adoption_gates_reference_data_and_preserves_barcode_reservations`: حوزه 02 هیچ proposedی از API نمی‌دهد؛ backend فقط `approved` را provision می‌کند. |
| REF-04 | PASS | `test_custom_category_deactivation_preserves_products_and_can_reactivate`: custom بدون کپی proposal ساخته می‌شود. |
| REF-05 | PASS | جست‌وجوی نام/نمونه با یکسان‌سازی ی/ک فارسی فقط دسته‌های موجود را فیلتر می‌کند؛ unit و production-preview اثبات می‌کنند هیچ category/product تازه‌ای ساخته نمی‌شود. |
| AUTH-01 | PASS | store از `CurrentUser` می‌آید؛ تست‌های `test_store_personnel.py`, `test_sync.py` و قیود cross-store در `test_postgresql.py`. |
| AUTH-02 | PASS | suite کامل store/personnel/admin موجود؛ route تازه همان authorization service را استفاده می‌کند. |
| AUTH-03 | PASS | suite entitlement/personnel lease و local access بدون fallback؛ تغییری در این مرز داده نشده است. |
| AUTH-04 | PASS | account guard در edit/bulk preview-confirm، invoice scan/output و sync؛ `invoice-scan-output.test.ts`. |
| CAT-01 | PASS | system category در category API/sync immutable؛ intentهای محصول از validator مشترک عبور می‌کنند. |
| CAT-02 | PASS | code custom پایدار و rename بدون rotation؛ lifecycle deactivate/reactivate در تست backend. |
| CAT-03 | PASS | تست backend اثبات می‌کند deactivate محصول را جدا نمی‌کند و مقصد تازه رد می‌شود. |
| CAT-04 | PASS | create جدید بعد adoption بدون دسته 422؛ patchهای legacy در regression sync حفظ شده‌اند. |
| CAT-05 | PASS | `validate_category_for_new_intent` store/sector/active/approved را fail-closed بررسی می‌کند؛ قیود FK/unique migration. |
| CAT-06 | PASS | signup regression کامل و adoption transaction؛ هویت signup تغییر نکرده است. rollout gate هنوز خاموش است. |
| SEC-01 | PASS | marker `has_historical_inventory_usage` در migration و delete/catalog provisioning پایدار می‌شود؛ legacy adoption review را دور نمی‌زند. |
| SEC-02 | PASS | race واقعی adoption/first-create روی PostgreSQL اجرا شد؛ یا adoption برنده و create با 422 رد می‌شود، یا create برنده و adoption با 409 متوقف می‌شود. |
| SEC-03 | PASS | فرمان stale بدون دسته پس از adoption در مرز sync با 422 پایدار رد و محصول ساخته نمی‌شود؛ payload در outbox بازیابی‌پذیر client باقی می‌ماند. |
| BC-01 | PASS | تست backend و `barcode-domain.test.ts`/`invoice-scan-output.test.ts` مقدار exact، صفر آغازین، case و فاصله را حفظ می‌کنند. |
| BC-02 | PASS | transport terminator جدا و validation ASCII/checksum روشن در frontend/backend. |
| BC-03 | PASS | `inventory.service.test.ts` انتخاب durable قبل dispatch، ID ثابت و atomic Solo/Team را بررسی می‌کند؛ backend replay همان payload. |
| BC-04 | PASS | unique `(store_id,value)` روی reservation شامل retired/deleted؛ same-target retry idempotent؛ suite PostgreSQL schema را نصب می‌کند. |
| BC-05 | PASS | uniqueness store-scoped و resolver همیشه store عضویت جاری را filter می‌کند؛ cross-store constraints موجود. |
| BC-06 | PASS | rotation فقط confirm recategorization است؛ patch نام/قیمت/brand/image مسیر barcode را فراخوانی نمی‌کند و regression inventory سبز است. |
| BC-07 | PASS | دستهٔ custom و محصول وابسته همراه Data Matrix داخلی در یک batch Solo پذیرفته می‌شوند؛ replay همان ID/value را برمی‌گرداند و unit محلی atomicity را پوشش می‌دهد. |
| BC-08 | PASS | collision به conflict/recovery می‌رود؛ هیچ renumber/rebind خودکار در client یا server وجود ندارد. |
| BC-09 | PASS | renderer escape HTML می‌کند و unsupported/overlong را بدون تغییر مقدار رد می‌کند؛ `label-renderer.test.ts`. |
| MOVE-01 | PASS | component bulk و production-preview edit نشان می‌دهند cancel هیچ confirm، product write، outbox یا lifecycle write ایجاد نمی‌کند. |
| MOVE-02 | PASS | confirm یک transaction server، operation fingerprint و same-ID replay دارد؛ backend lifecycle test. |
| MOVE-03 | PASS | external alias دست‌نخورده و internalهای فعال retired/replaced؛ backend lifecycle test. |
| MOVE-04 | PASS | reservation retired قابل احیا نیست و rename مسیر صدور ندارد؛ validation server fail-closed است. |
| MOVE-05 | PASS | دو recategorization همزمان روی PostgreSQL واقعی دقیقاً یک 200 و یک 409 stale می‌دهند؛ یک active و یک retired باقی می‌ماند. |
| MOVE-06 | PASS | token HMAC به target/version/count/destination/expiry مقید و stale snapshot با 409 رد می‌شود؛ UI preview را دوباره می‌خواهد. |
| MOVE-07 | PASS | edit و bulk تنها entry pointهای تغییر مستقیم category هستند و هر دو preview/confirm می‌خواهند؛ import فقط create می‌کند و validation adoption را دور نمی‌زند، catalog category را patch نمی‌کند و restore با current-over-import رکورد موجود را recategorize نمی‌کند. |
| MOVE-08 | PASS | fault injection پس از issue جایگزین روی PostgreSQL، category/barcode/reservation و `SyncOperation` را همگی rollback می‌کند. |
| MOVE-09 | N/A | هیچ مدل variant مستقل در مدل‌ها/schema/Dexie وجود ندارد؛ سند معماری مسیرهای منبع را ثبت کرده است. |
| MODE-01 | PASS | Solo product+barcode+outbox در `localMutationStorage.inventoryWithBarcodes` یک Dexie transaction است؛ `inventory.service.test.ts`. |
| MODE-02 | PASS | Team create barcode projection خوش‌بینانه ندارد؛ offline از team command service رد می‌شود؛ regression موجود. |
| MODE-03 | PASS | suite sync/replay و `sync-resolution-real.spec.ts` همان ID/fingerprint و late resolution را پوشش می‌دهند. |
| MODE-04 | PASS | conditional rollback/successor logic suite sync client موجود و بدون تغییر حفظ شده است. |
| MODE-05 | PASS | attempted/unknown/renewal regressionهای فاز 09B و read-only resolution حفظ شده‌اند. |
| SCAN-01 | PASS | resolver retired را جدا می‌کند؛ invoice test صفر effect و scanner page هیچ pending movement برای retired نمی‌سازد. |
| SCAN-02 | PASS | resolver exact و ambiguity fail-closed؛ `invoice-scan-output.test.ts`. |
| SCAN-03 | PASS | callback dedupe/camera close/account guard در scanner component regression موجود. |
| SCAN-04 | PASS | movement پذیرش server barcode id/value/lifecycle را دوباره بررسی می‌کند؛ stale intent رد می‌شود. |
| SCAN-05 | PASS | invoice capability مستقل از barcode lookup؛ `invoice-scan-output.test.ts` و invoice browser regression. |
| PRINT-01 | PASS | هویت داخلی ۴۸نویسه‌ای Data Matrix ECC200 با bwip-js encode و با ZXing exact decode شد؛ validator و production-preview هر دو profile حرارتی و A4 را بدون overflow پوشش می‌دهند. |
| PRINT-02 | PASS | Team پیش از acceptance barcode project نمی‌کند؛ Solo pending state در output snapshot مشخص است؛ invoice output test. |
| PRINT-03 | NOT RUN | scanner/camera/printer فیزیکی در محیط موجود نیست. |
| MIG-01 | PASS | migration rehearsal واقعی PostgreSQL از revisionهای قدیمی تا head؛ ID/value/quantity/prices/history/fingerprint و reference counts حفظ شده‌اند. |
| MIG-02 | PASS | preflight/rollback fixtureهای ambiguous catalog، owner و phone در `test_postgresql.py`؛ schema/data پس از شکست حفظ می‌شود. |
| MIG-03 | PASS | legacy category/uncategorized/origin بدون inference حفظ می‌شود؛ migration evidence و service compatibility. |
| MIG-04 | PASS | fingerprint عملیات committed قدیمی حفظ و replay می‌شود؛ intent تازهٔ ناسازگار از validator adoption عبور نمی‌کند. |
| REC-01 | PASS | backup schema 6 و reader 1..6؛ authority جزو envelope نیست؛ backup suites. |
| REC-02 | PASS | current-over-import بر ID و resolver ambiguity مانع resurrection/rebind خاموش است؛ sync server reservation را authoritative می‌داند. |
| REC-03 | PASS | backup/restore unit و browser suite quota/restart/staging/apply/discard را پوشش می‌دهند. |
| SYNC-01 | PASS | barcode/category snapshots partitioned، pending successor guard و sync changes recategorization؛ sync suites. |
| SYNC-02 | PASS | catalog reconcile concurrency/capacity در `test_postgresql.py`; overrides و inventory record موجود حفظ می‌شوند. |
| PWA-01 | PASS | Dexie version عوض نشده؛ `local-database-upgrade.test.ts` و real PWA harness داده/صف را حفظ می‌کنند. |
| PWA-02 | PASS | contract محلی schema تازه‌ای ندارد؛ `pwa-update-real.spec.ts` همان two-build harness موجود است. |
| UX-01 | PASS | production-preview شامل gate، راهنمای نمونه، cancel/confirm، projection بازنشسته/فعال، leading-zero exact، retired guidance و label در desktop/mobile است؛ dark/large و light/default پوشش داده شده‌اند. |
| REG-01 | PASS | frontend/backend کامل، typecheck/lint/build و focused browser suite باید در بخش اجرای نهایی همین سند سبز ثبت شوند. |

## گیت انتشار و تصمیم باز

`TAXONOMY_ADOPTION_ENABLED` باید در همهٔ محیط‌ها `false` بماند. فعال‌کردن آن فقط پس از این موارد مجاز است:

موارد خودکار تصمیم Data Matrix، PRINT-01، race/fault-injection و production-preview انجام و PASS شده‌اند. موارد باز rollout:

1. تست فیزیکی چاپ/اسکن/دوربین یا ثبت صریح پذیرش عملیاتیِ باقی‌ماندن آن به‌عنوان blocker rollout؛
2. بازبینی انتشار و تغییر صریح configuration در محیط مقصد؛ این commit هیچ فعال‌سازی مشتری انجام نمی‌دهد؛
3. ۲۵۶ دستهٔ پیشنهادی سایر حوزه‌ها تا تصویب تجاری مستقل همچنان `proposed` و غیرقابل provision می‌مانند.

تا آن زمان این کد «زیرساخت gated» است، نه «آمادهٔ مشتری».

## اجرای نهایی ۱۴۰۵/۰۸/۲۵ (2026-11-16)

| کنترل | نتیجه |
|---|---|
| validator بستهٔ v1.1 | PASS؛ 24 sector، 281 category، 25 approved، 256 proposed-disabled و 62 scenario؛ همهٔ hashهای manifest مطابق. |
| `npm.cmd test` | PASS؛ 90 فایل و 414 تست frontend/component. |
| `npm.cmd run test:backend` | PASS؛ 104 تست backend بدون suite جداگانهٔ PostgreSQL. |
| `npm.cmd run test:backend:postgres:local` | PASS؛ 22 تست روی PostgreSQL 18.6 محلی و دیتابیس ایزولهٔ `tanzim_test`؛ شامل raceهای adoption/recategorization و fault injection. |
| `npm.cmd run test:typecheck` | PASS؛ exit 0. |
| `npm.cmd run lint` | PASS؛ exit 0. |
| `npm.cmd run build` | PASS؛ production build با Vite 8.0.16. هشدار اندازهٔ chunk و browserslist موجود است و failure نیست. |
| Playwright production preview | PASS؛ 10 journey در Chromium desktop/mobile برای gate، جست‌وجوی نمونه، cancel/confirm تغییر دسته، projection کد active/retired، exact leading-zero، راهنمای retired و Data Matrix در هر دو profile. API این مجموعه fixture مصنوعی است. |
| Data Matrix encode/decode | PASS؛ طول نهایی ۴۸ نویسه با bwip-js به ۲۴×۲۴ encode و با ZXing به همان مقدار exact decode شد؛ هر دو profile validator را گذراندند. |
| focused exact external regression | PASS؛ 2 تست backend taxonomy/lifecycle، شامل حفظ فاصله/case/leading zero و عدم exact-match پس از trim. |
| `git diff --check` | PASS؛ خروجی خالی. |
| تجهیزات فیزیکی | NOT RUN؛ scanner/camera/printer در محیط موجود نبود. |

مرز شواهد: PostgreSQL واقعی محلی و مرورگر Chromium واقعی استفاده شد، ولی APIهای journey مرورگر focused با fixture مصنوعی mock شده‌اند. app-to-backend واقعی برای migration/lifecycle در TestClient و PostgreSQL suite اجرا شده، نه در همان Playwright process. هیچ تستی روی داده یا حساب مشتری اجرا نشده است.
